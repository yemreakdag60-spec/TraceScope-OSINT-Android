# TraceScope OSINT Pro v1.3.0 — Architecture

## Katmanlar
- **UI:** Jetpack Compose, koyu/premium TraceScope tasarımı, Ana Sayfa / Araştır / Korelasyon / Rapor / Ayarlar.
- **ViewModel:** araştırma modlarını, derin taramayı ve hata izolasyonunu orkestre eder.
- **PhoneEngine:** libphonenumber + BTK/e-Devlet operatör doğrulama yönlendirmesi.
- **EmailEngine:** sağlayıcı, yerel parça, kimlik tokenları ve kullanıcı adı adayları.
- **UsernameEngine:** kaynak kayıt defteri, varyasyon, profil probing, güven/durum sınıflandırması.
- **PublicIntelExtractor:** açık HTML/meta/JSON-LD/mailto/tel/sameAs sinyalleri.
- **PublicWebsiteEnricher:** profilden çıkan açık web sitelerinde aynı-domain contact/about sayfalarına sınırlı bir adım zenginleştirme.
- **DomainEngine:** Google DNS-over-HTTPS ile MX/SPF/DMARC; RDAP pivotu.
- **ContactCorrelationEngine:** e-posta↔telefon açık-web sorgu pivotları.
- **PersonEvidenceEngine:** kişi sinyallerini izlenebilir, açıklanabilir kapsam skorunda birleştirir.
- **CorrelationEngine:** profil çiftlerinde ortak açık e-posta/telefon/domain/ad/konum korelasyonu.
- **ReportWriter:** PDF/JSON.

## Güvenilirlik ilkeleri
1. HTTP 200 tek başına hesap varlığı değildir.
2. Platform bot/oturum duvarı döndürürse “Tarayıcı doğrulaması” denir.
3. Taşınabilir numarada blok operatörü güncel operatör diye sunulmaz.
4. Gizli kayıt verisi tahmin edilmez veya uydurulmaz.
5. Yerel/özel ağ URL'lerine otomatik istek gönderilmez.
6. Bir kaynak hata verirse diğer kaynaklar devam eder.
7. Skor kimlik doğrulaması değil, açık kanıt kapsamıdır.

## Tarama sınırları
Derin tarama; performans, yanlış pozitif ve servis yükünü dengelemek için kullanıcı adı varyasyonlarını, eşzamanlı istek sayısını ve bağlı web sayfası sayısını bilinçli olarak sınırlar.
