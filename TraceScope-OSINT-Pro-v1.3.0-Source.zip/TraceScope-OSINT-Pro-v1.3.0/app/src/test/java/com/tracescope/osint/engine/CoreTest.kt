package com.tracescope.osint.engine

import com.tracescope.osint.model.*
import org.junit.Assert.*
import org.junit.Test

class CoreTest {
    @Test
    fun usernameVariantsContainUsefulForms() {
        val v = UsernameVariantGenerator.generate("Emre.Akdag")
        assertTrue(v.contains("emre.akdag"))
        assertTrue(v.contains("emreakdag"))
        assertTrue(v.contains("akdagemre"))
    }

    @Test
    fun correlationRewardsSharedPublicEmail() {
        val s1 = PlatformSource("A", "https://a/%s")
        val s2 = PlatformSource("B", "https://b/%s")
        val a = ProfileHit(s1, "user.one", "", "", ProbeState.LIKELY, Confidence.MEDIUM, 200, 10, "", PublicClues(displayName = "User One", emails = listOf("same@example.org")))
        val b = ProfileHit(s2, "user_one", "", "", ProbeState.LIKELY, Confidence.MEDIUM, 200, 10, "", PublicClues(displayName = "User One", emails = listOf("same@example.org")))
        val pair = CorrelationEngine.pairwise(listOf(a, b)).first()
        assertTrue(pair.score >= 50)
        assertTrue(pair.reasons.any { it.contains("e-posta") })
    }
    @Test
    fun contactCorrelationDetectsEmailDirection() {
        val result = ContactCorrelationEngine.analyze("test.user@gmail.com")
        assertEquals(ContactDirection.EMAIL_TO_PHONE, result.direction)
        assertEquals("Google / Gmail", result.providerHint)
        assertTrue(result.searchPivots.isNotEmpty())
    }

    @Test
    fun contactCorrelationDetectsPhoneDirection() {
        val result = ContactCorrelationEngine.analyze("+90 532 123 45 67")
        assertEquals(ContactDirection.PHONE_TO_EMAIL, result.direction)
        assertTrue(result.phoneVariants.isNotEmpty())
        assertTrue(result.searchPivots.any { it.first.contains("Gmail") })
    }

    @Test
    fun emailEngineBuildsIdentityTokensAndCandidates() {
        val result = EmailEngine.analyze("emre.akdag60@gmail.com")
        assertTrue(result.valid)
        assertTrue(result.identityTokens.contains("emre"))
        assertTrue(result.identityTokens.contains("akdag"))
        assertTrue(result.usernameCandidates.isNotEmpty())
    }

    @Test
    fun publicExtractorReadsMailtoTelAndJsonLd() {
        val html = """
            <html><head><meta property="og:title" content="Example User"></head>
            <body>
              <a href="mailto:user@example.org">mail</a>
              <a href="tel:+905321234567">phone</a>
              <script type="application/ld+json">{"telephone":"+905321234567","email":"user@example.org","sameAs":["https://github.com/example"]}</script>
            </body></html>
        """.trimIndent()
        val clues = PublicIntelExtractor.extract(html, "https://example.org/profile")
        assertTrue(clues.emails.contains("user@example.org"))
        assertTrue(clues.phones.contains("+905321234567"))
        assertTrue(clues.websites.any { it.contains("github.com/example") })
    }

    @Test
    fun personEvidenceScoreIsExplainable() {
        val source = PlatformSource("GitHub", "https://github.com/%s", true)
        val hit = ProfileHit(
            source, "example", "", "https://github.com/example",
            ProbeState.CONFIRMED, Confidence.HIGH, 200, 12, "",
            PublicClues(displayName = "Example User", emails = listOf("user@example.org"), phones = listOf("+905321234567"))
        )
        val intel = UsernameIntel(
            input = "example", variants = listOf("example"), profiles = listOf(hit),
            publicEmails = listOf("user@example.org"), publicPhones = listOf("+905321234567"),
            locationSignals = emptyList(), websites = listOf("https://example.org"),
            displayNames = listOf("Example User"), sourcesAttempted = 1
        )
        val summary = PersonEvidenceEngine.summarize(intel, null, null)
        assertTrue(summary.evidenceScore > 0)
        assertTrue(summary.reasons.isNotEmpty())
    }

}
