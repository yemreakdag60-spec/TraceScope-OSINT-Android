package com.tracescope.osint

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tracescope.osint.engine.CorrelationEngine
import com.tracescope.osint.model.*
import com.tracescope.osint.report.ReportWriter
import com.tracescope.osint.ui.theme.TraceScopeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TraceScopeTheme { TraceScopeApp() } }
    }
}

private enum class AppTab(val label: String, val icon: ImageVector) {
    HOME("Ana Sayfa", Icons.Default.Home),
    SEARCH("Araştır", Icons.Default.Search),
    CORRELATION("Korelasyon", Icons.Default.Hub),
    REPORT("Rapor", Icons.Default.Description),
    SETTINGS("Ayarlar", Icons.Default.Settings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TraceScopeApp(vm: TraceScopeViewModel = viewModel()) {
    var tab by remember { mutableStateOf(AppTab.HOME) }
    val state by vm.state

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("TraceScope OSINT", fontWeight = FontWeight.Black)
                                Spacer(Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = MaterialTheme.colorScheme.secondary.copy(alpha = .16f)
                                ) {
                                    Text("PRO", Modifier.padding(horizontal = 7.dp, vertical = 3.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                            Text("Public-source intelligence · v1.3.0", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                AppTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = tab == item,
                        onClick = { tab = item },
                        icon = { Icon(item.icon, item.label) },
                        label = { Text(item.label, maxLines = 1, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                AppTab.HOME -> HomeScreen(onSearch = { mode -> vm.setMode(mode); tab = AppTab.SEARCH }, result = state.result)
                AppTab.SEARCH -> SearchScreen(state, vm)
                AppTab.CORRELATION -> CorrelationScreen(state.result)
                AppTab.REPORT -> ReportScreen(state.result)
                AppTab.SETTINGS -> SettingsScreen()
            }
        }
    }
}

@Composable
private fun HomeScreen(onSearch: (SearchMode) -> Unit, result: SearchBundle?) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            HeroCard()
        }
        item {
            Text("Araştırma modülleri", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleCard("Telefon", "Numara biçimi, ilk tahsis bloğu, BTK doğrulama ve web pivotları", Icons.Default.Phone, Modifier.weight(1f)) { onSearch(SearchMode.PHONE) }
                ModuleCard("Kullanıcı adı", "Instagram, Facebook, X, TikTok ve diğer platformlarda varyasyon/korelasyon", Icons.Default.PersonSearch, Modifier.weight(1f)) { onSearch(SearchMode.USERNAME) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleCard("E-posta", "Sağlayıcı, kimlik parçaları, çoklu kullanıcı adı taraması ve açık kişi sinyalleri", Icons.Default.Email, Modifier.weight(1f)) { onSearch(SearchMode.EMAIL) }
                ModuleCard("E-posta ↔ Telefon", "Gmail/Outlook dahil açık webde çift yönlü iletişim ve kişi korelasyonu", Icons.Default.SyncAlt, Modifier.weight(1f)) { onSearch(SearchMode.CONTACT_LINK) }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModuleCard("IP", "Bilinen IP için yaklaşık ağ konumu ve ISP", Icons.Default.Language, Modifier.weight(1f)) { onSearch(SearchMode.IP) }
                ModuleCard("Korelasyon", "Hesaplar arası ortak açık sinyalleri puanlar", Icons.Default.Hub, Modifier.weight(1f)) { onSearch(SearchMode.USERNAME) }
            }
        }
        item {
            InfoCard(
                "Korelasyon motoru",
                "Farklı kullanıcı adlarını; görünen ad, ortak açık e-posta/telefon, web alan adı ve konum sinyalleriyle ilişkilendirir. Tek bir işareti kesin kimlik olarak kabul etmez.",
                Icons.Default.AccountTree
            )
        }
        item {
            InfoCard(
                "Kaynak-temelli rapor",
                "Her bulgu durum, güven seviyesi, URL, HTTP sonucu ve gecikme bilgisiyle kaydedilir. PDF/JSON dışa aktarma mevcuttur.",
                Icons.Default.FactCheck
            )
        }
        if (result != null) item {
            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Son araştırma", fontWeight = FontWeight.Bold)
                    Text("${result.mode.label}: ${result.query}")
                }
            }
        }
    }
}

@Composable
private fun HeroCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column(
            Modifier
                .background(Brush.linearGradient(listOf(Color(0xFF0B3150), Color(0xFF102A45), Color(0xFF241C4F))))
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = .14f)) {
                    Icon(Icons.Default.Shield, null, modifier = Modifier.padding(12.dp).size(36.dp), tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("TraceScope OSINT Pro", fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("Evidence-driven public-source intelligence", fontSize = 12.sp, color = Color(0xFFBFD9EB))
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("E-posta, kullanıcı adı ve telefon sinyallerini tek kanıt görünümünde birleştirir; kaynak, güven, kapsama ve çapraz doğrulama bilgisiyle gösterir.", color = Color(0xFFE5F4FF))
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallBadge("Kaynak")
                SmallBadge("Korelasyon")
                SmallBadge("BTK doğrulama")
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallBadge("PDF/JSON")
                SmallBadge("Kanıt skoru")
                SmallBadge("HTTPS")
            }
        }
    }
}

@Composable
private fun SmallBadge(text: String) {
    Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.primary.copy(alpha = .12f)) {
        Text(text, Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
    }
}

@Composable
private fun ModuleCard(title: String, subtitle: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier.clickable(onClick = onClick), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp).heightIn(min = 138.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f), maxLines = 4, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, icon: ImageVector) {
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(body, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchScreen(state: SearchUiState, vm: TraceScopeViewModel) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            androidx.compose.foundation.lazy.LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(SearchMode.entries) { mode ->
                    FilterChip(
                        selected = state.mode == mode,
                        onClick = { vm.setMode(mode) },
                        label = { Text(mode.label, fontSize = 12.sp) },
                        leadingIcon = { Icon(iconFor(mode), null, modifier = Modifier.size(17.dp)) }
                    )
                }
            }
        }
        item {
            OutlinedTextField(
                value = state.query,
                onValueChange = vm::setQuery,
                label = { Text(placeholderFor(state.mode)) },
                leadingIcon = { Icon(iconFor(state.mode), null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }
        if (state.mode in setOf(SearchMode.USERNAME, SearchMode.EMAIL, SearchMode.CONTACT_LINK)) item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Derin tarama", fontWeight = FontWeight.SemiBold)
                    Text("Varyasyon, çapraz platform ve bağlı web sitesi zenginleştirmesi", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
                }
                Switch(checked = state.deepScan, onCheckedChange = vm::setDeepScan)
            }
        }
        item {
            Button(onClick = vm::search, enabled = !state.loading, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                if (state.loading) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Kaynaklar taranıyor…")
                } else {
                    Icon(Icons.Default.Radar, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Araştırmayı başlat")
                }
            }
        }
        state.message?.let { msg -> item { AssistChip(onClick = {}, label = { Text(msg) }, leadingIcon = { Icon(Icons.Default.Info, null) }) } }
        item {
            Text("Yalnızca kamuya açık/izinli kaynaklar kullanılır. Otomatik erişimi engelleyen platformlar 'Tarayıcıda doğrula' olarak işaretlenir; sahte pozitif kesin hesap diye sunulmaz.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f))
        }
        state.result?.let { result ->
            when (result.mode) {
                SearchMode.PHONE -> {
                    result.phone?.let { p -> item { PhoneResultCard(p) } }
                    result.contact?.let { c -> item { ContactCorrelationCard(c) } }
                }
                SearchMode.EMAIL -> {
                    result.email?.let { e -> item { EmailResultCard(e) } }
                    result.domain?.let { d -> item { DomainIntelCard(d) } }
                    result.contact?.let { c -> item { ContactCorrelationCard(c) } }
                    result.person?.let { person -> item { PublicPersonSummaryCard(person, "E-posta ve türetilen kullanıcı adı adaylarından birleştirilen kamuya açık kişi sinyalleri") } }
                    result.username?.let { u ->
                        item { UsernameSummary(u) }
                        items(u.profiles.filter { it.state != ProbeState.NOT_FOUND }) { hit -> ProfileCard(hit) }
                    }
                }
                SearchMode.CONTACT_LINK -> {
                    result.phone?.let { p -> item { PhoneResultCard(p) } }
                    result.email?.let { e -> item { EmailResultCard(e) } }
                    result.domain?.let { d -> item { DomainIntelCard(d) } }
                    result.contact?.let { c -> item { ContactCorrelationCard(c) } }
                    result.person?.let { person -> item { PublicPersonSummaryCard(person, "İletişim bilgisinden türetilen kamuya açık kişi sinyalleri") } }
                    result.username?.let { u -> item { UsernameSummary(u) } }
                }
                SearchMode.IP -> result.ip?.let { i -> item { IpResultCard(i) } }
                SearchMode.USERNAME -> result.username?.let { u ->
                    result.person?.let { person -> item { PublicPersonSummaryCard(person, "Kullanıcı adından ve varyasyonlarından birleştirilen kamuya açık kişi sinyalleri") } }
                    item { UsernameSummary(u) }
                    items(u.profiles.filter { it.state != ProbeState.NOT_FOUND }) { hit -> ProfileCard(hit) }
                    val missing = u.profiles.count { it.state == ProbeState.NOT_FOUND }
                    if (missing > 0) item { Text("$missing kaynakta hesap bulunamadı.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .55f)) }
                }
            }
        }
    }
}

@Composable
private fun PhoneResultCard(p: PhoneIntel) {
    val context = LocalContext.current
    ResultCard("Telefon analizi", Icons.Default.Phone) {
        KeyValue("Geçerli", if (p.valid) "Evet" else "Hayır")
        KeyValue("Olası", if (p.possible) "Evet" else "Hayır")
        if (p.international.isNotBlank()) KeyValue("Uluslararası", p.international)
        if (p.e164.isNotBlank()) KeyValue("E.164", p.e164)
        if (p.regionCode.isNotBlank()) KeyValue("Ülke/bölge", p.regionCode)
        if (p.type.isNotBlank()) KeyValue("Hat türü", p.type)
        if (p.carrier.isNotBlank()) KeyValue("İlk tahsis / numara bloğu", p.carrier)
        KeyValue("Güncel operatör", "Resmî doğrulama gerekli")
        if (p.regionCode == "TR" && p.e164.isNotBlank()) {
            OutlinedButton(
                onClick = { openUrl(context, p.operatorVerificationUrl.ifBlank { btkOperatorUrl(p.e164) }) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Verified, null)
                Spacer(Modifier.width(8.dp))
                Text("BTK / e-Devlet güncel operatör sorgusu")
            }
        }
        if (p.geographicDescription.isNotBlank()) KeyValue("Numara bölgesi", p.geographicDescription)
        if (p.timeZones.isNotEmpty()) KeyValue("Saat dilimi", p.timeZones.joinToString())
        p.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        p.webPivots.forEach { (name, url) ->
            OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text(name)
            }
        }
        Text("İlk tahsis bilgisi numara bloğu verisidir. Numara taşındıysa mevcut operatör farklı olabilir. Türkiye'de güncel işletmeci için resmî BTK/e-Devlet sorgusu açılır; TraceScope sonucu uydurmaz. Bölge bilgisi canlı konum değildir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
    }
}

@Composable
private fun EmailResultCard(e: EmailIntel) {
    val context = LocalContext.current
    ResultCard("E-posta analizi", Icons.Default.Email) {
        KeyValue("Geçerli biçim", if (e.valid) "Evet" else "Hayır")
        if (e.domain.isNotBlank()) KeyValue("Alan adı", e.domain)
        if (e.providerLabel.isNotBlank()) KeyValue("Sağlayıcı", e.providerLabel)
        if (e.identityTokens.isNotEmpty()) KeyValue("Kimlik parçaları", e.identityTokens.joinToString())
        if (e.usernameCandidates.isNotEmpty()) KeyValue("Kullanıcı adı adayları", e.usernameCandidates.joinToString())
        e.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        e.webPivots.forEach { (name, url) ->
            OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text(name)
            }
        }
        if (e.domainPivots.isNotEmpty()) {
            Text("Alan adı istihbaratı", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            e.domainPivots.forEach { (name, url) ->
                OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Language, null); Spacer(Modifier.width(8.dp)); Text(name)
                }
            }
        }
        Text("E-posta yerel parçasından kullanıcı adı adayları otomatik taranır. Bu eşleşmeler kişi kimliğini tek başına kanıtlamaz; açık telefon/e-posta/konum gibi ek sinyallerle değerlendirilir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
    }
}

@Composable
private fun DomainIntelCard(d: DomainIntel) {
    val context = LocalContext.current
    ResultCard("Alan adı güven ve posta altyapısı", Icons.Default.Dns) {
        KeyValue("Alan adı", d.domain)
        if (d.mxHosts.isNotEmpty()) KeyValue("MX sunucuları", d.mxHosts.take(6).joinToString())
        KeyValue("SPF", if (d.spfRecords.isNotEmpty()) "Bulundu" else "Görünmedi")
        KeyValue("DMARC", if (d.dmarcRecords.isNotEmpty()) "Bulundu" else "Görünmedi")
        if (d.notes.isNotEmpty()) d.notes.forEach { Text("• $it", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)) }
        d.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (d.rdapLookupUrl.isNotBlank()) {
            OutlinedButton(onClick = { openUrl(context, d.rdapLookupUrl) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.ManageSearch, null)
                Spacer(Modifier.width(8.dp))
                Text("RDAP alan adı kaydını aç")
            }
        }
        Text("Bu bölüm kişi kimliği çıkarmaz; e-posta alan adının teknik ve açık kayıt bağlamını güçlendirir.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f))
    }
}

@Composable
private fun ContactCorrelationCard(c: ContactCorrelationIntel) {
    val context = LocalContext.current
    ResultCard("E-posta ↔ Telefon korelasyonu", Icons.Default.SyncAlt) {
        KeyValue("Yön", c.direction.label)
        KeyValue("Normalize giriş", c.normalizedInput)
        if (c.providerHint.isNotBlank()) {
            KeyValue(if (c.direction == ContactDirection.PHONE_TO_EMAIL) "İlk tahsis / numara bloğu" else "E-posta sağlayıcısı", c.providerHint)
        }
        if (c.direction == ContactDirection.PHONE_TO_EMAIL && c.normalizedInput.startsWith("+90")) {
            KeyValue("Güncel operatör", "Resmî doğrulama gerekli")
            OutlinedButton(
                onClick = { openUrl(context, btkOperatorUrl(c.normalizedInput)) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Verified, null)
                Spacer(Modifier.width(8.dp))
                Text("BTK / e-Devlet güncel operatör sorgusu")
            }
        }
        if (c.usernameCandidates.isNotEmpty()) KeyValue("Kullanıcı adı adayları", c.usernameCandidates.joinToString())
        if (c.phoneVariants.isNotEmpty()) KeyValue("Numara varyasyonları", c.phoneVariants.joinToString())
        c.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        c.searchPivots.forEach { (name, url) ->
            OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null)
                Spacer(Modifier.width(8.dp))
                Text(name)
            }
        }
        c.notes.forEach { Text("• $it", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .62f)) }
    }
}

@Composable
private fun IpResultCard(i: IpIntel) {
    ResultCard("IP analizi", Icons.Default.Language) {
        if (!i.success) Text(i.note, color = MaterialTheme.colorScheme.error)
        else {
            KeyValue("IP", i.ip)
            KeyValue("Konum", listOf(i.city, i.region, i.country).filter { it.isNotBlank() }.joinToString(", "))
            KeyValue("ISP", i.isp)
            KeyValue("ASN", i.asn)
            if (i.latitude != null && i.longitude != null) KeyValue("Yaklaşık koordinat", "${i.latitude}, ${i.longitude}")
            Text(i.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
        }
    }
}

@Composable
private fun UsernameSummary(u: UsernameIntel) {
    val context = LocalContext.current
    ResultCard("Kullanıcı adı istihbaratı", Icons.Default.PersonSearch) {
        val confirmed = u.profiles.count { it.state == ProbeState.CONFIRMED }
        val likely = u.profiles.count { it.state == ProbeState.LIKELY }
        val ambiguous = u.profiles.count { it.state == ProbeState.AMBIGUOUS }
        KeyValue("Kaynak denemesi", u.sourcesAttempted.toString())
        KeyValue("Doğrulanan", confirmed.toString())
        KeyValue("Muhtemel", likely.toString())
        KeyValue("Belirsiz", ambiguous.toString())
        if (u.displayNames.isNotEmpty()) KeyValue("Görünen adlar", u.displayNames.joinToString())
        if (u.publicEmails.isNotEmpty()) KeyValue("Açık e-posta", u.publicEmails.joinToString())
        if (u.publicPhones.isNotEmpty()) KeyValue("Açık telefon", u.publicPhones.joinToString())
        if (u.locationSignals.isNotEmpty()) KeyValue("Açık konum sinyali", u.locationSignals.joinToString())
        if (u.websites.isNotEmpty()) KeyValue("Bağlantılı web", u.websites.take(6).joinToString())
        if (u.websiteEvidence.isNotEmpty()) {
            KeyValue("Web zenginleştirme", "${u.websiteEvidence.size} açık site/iletişim sayfası incelendi")
            u.websiteEvidence.take(4).forEach { w ->
                val found = buildList {
                    if (w.emails.isNotEmpty()) add("${w.emails.size} e-posta")
                    if (w.phones.isNotEmpty()) add("${w.phones.size} telefon")
                    if (w.locations.isNotEmpty()) add("${w.locations.size} konum")
                    if (w.socialLinks.isNotEmpty()) add("${w.socialLinks.size} sosyal bağlantı")
                }.joinToString(" · ").ifBlank { "iletişim sinyali yok" }
                Text("• ${w.url.take(54)} — $found", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f))
            }
        }
        Text("Varyasyonlar: ${u.variants.joinToString()}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
        if (u.webPivots.isNotEmpty()) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .25f))
            Text("Açık web pivotları", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            u.webPivots.forEach { (name, url) ->
                OutlinedButton(onClick = { openUrl(context, url) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.TravelExplore, null)
                    Spacer(Modifier.width(8.dp))
                    Text(name)
                }
            }
        }
    }
}

@Composable
private fun PublicPersonSummaryCard(person: PublicPersonSummary, subtitle: String) {
    ResultCard("Kişi kanıt özeti", Icons.Default.Badge) {
        Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .66f))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = .11f),
                modifier = Modifier.size(72.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("%${person.evidenceScore}", fontSize = 20.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                }
            }
            Column(Modifier.weight(1f)) {
                Text(person.evidenceLabel, fontWeight = FontWeight.Bold)
                Text("${person.sourceCount} kaynak · ${person.profileHits.size} profil adayı", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .60f))
                LinearProgressIndicator(progress = person.evidenceScore / 100f, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            }
        }
        if (person.names.isNotEmpty()) KeyValue("Görünen ad", person.names.take(6).joinToString())
        if (person.emails.isNotEmpty()) KeyValue("Açık e-posta", person.emails.take(8).joinToString())
        if (person.phones.isNotEmpty()) KeyValue("Açık telefon", person.phones.take(8).joinToString())
        if (person.locations.isNotEmpty()) KeyValue("Konum sinyali", person.locations.take(8).joinToString())
        if (person.websites.isNotEmpty()) KeyValue("Web/domain", person.websites.take(8).joinToString())
        if (person.blockedCount > 0 || person.errorCount > 0) {
            KeyValue("Kaynak sağlığı", "${person.blockedCount} engelli/doğrulama · ${person.errorCount} hata")
        }
        if (person.reasons.isNotEmpty()) {
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .25f))
            Text("Skoru oluşturan sinyaller", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            person.reasons.take(8).forEach { Text("• $it", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .66f)) }
        }
        Text("Kanıt skoru kimlik doğrulaması değildir; yalnızca kamuya açık ve izlenebilir sinyallerin kapsamını özetler. Gizli kayıt telefonu/e-postası, özel hesap verisi veya canlı konum çıkarılmaz.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .52f))
    }
}

@Composable
private fun ProfileCard(hit: ProfileHit) {
    val context = LocalContext.current
    OutlinedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(hit.source.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                StatusBadge(hit.state, hit.confidence)
            }
            Text("@${hit.username}", color = MaterialTheme.colorScheme.primary)
            Text(hit.note, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
            hit.clues.displayName?.let { if (it.isNotBlank()) KeyValue("Görünen ad", it) }
            if (hit.clues.emails.isNotEmpty()) KeyValue("Açık e-posta", hit.clues.emails.joinToString())
            if (hit.clues.phones.isNotEmpty()) KeyValue("Açık telefon", hit.clues.phones.joinToString())
            if (hit.clues.locations.isNotEmpty()) KeyValue("Konum sinyali", hit.clues.locations.joinToString())
            Text("HTTP ${hit.httpCode ?: "-"} • ${hit.latencyMs} ms", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .45f))
            OutlinedButton(onClick = { openUrl(context, hit.finalUrl) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.OpenInNew, null); Spacer(Modifier.width(8.dp)); Text("Kaynağı aç")
            }
        }
    }
}

@Composable
private fun StatusBadge(state: ProbeState, confidence: Confidence) {
    val (text, color) = when (state) {
        ProbeState.CONFIRMED -> "Doğrulandı" to Color(0xFF37E7A1)
        ProbeState.LIKELY -> "Muhtemel" to Color(0xFF25C7FF)
        ProbeState.AMBIGUOUS -> "Belirsiz" to Color(0xFFFFC857)
        ProbeState.BLOCKED -> "Tarayıcı doğrulaması" to Color(0xFFFF9F43)
        ProbeState.ERROR -> "Hata" to Color(0xFFFF6B6B)
        ProbeState.NOT_FOUND -> "Yok" to Color.Gray
    }
    Surface(color = color.copy(alpha = .14f), shape = RoundedCornerShape(999.dp)) {
        Text("$text · ${confidence.label}", Modifier.padding(horizontal = 9.dp, vertical = 4.dp), fontSize = 10.sp, color = color)
    }
}

@Composable
private fun ResultCard(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(Modifier.fillMaxWidth(), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .35f))
            content()
        }
    }
}

@Composable
private fun KeyValue(key: String, value: String) {
    if (value.isBlank()) return
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(key, modifier = Modifier.width(118.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .58f))
        Text(value, modifier = Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun CorrelationScreen(result: SearchBundle?) {
    val username = result?.username
    if (username == null) {
        EmptyState(Icons.Default.Hub, "Korelasyon için önce kullanıcı adı araştırması yapın.")
        return
    }
    val pairs = remember(username) { CorrelationEngine.pairwise(username.profiles).filter { it.score > 0 } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Kimlik korelasyonu", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Skor, aynı kişi olduğunu kanıtlamaz; ortak açık kaynak sinyallerinin gücünü özetler.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
        }
        if (pairs.isEmpty()) item { EmptyCard("Yeterli ortak sinyal bulunmadı.") }
        items(pairs.take(50)) { pair ->
            OutlinedCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${pair.left.source.name} ↔ ${pair.right.source.name}", fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = pair.score / 100f, modifier = Modifier.fillMaxWidth())
                    Text("Eşleşme sinyali: %${pair.score}", color = MaterialTheme.colorScheme.primary)
                    pair.reasons.forEach { Text("• $it", fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun ReportScreen(result: SearchBundle?) {
    val context = LocalContext.current
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null && result != null) runCatching { ReportWriter(context).writePdf(uri, result) }
    }
    val jsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null && result != null) runCatching { ReportWriter(context).writeJson(uri, result) }
    }
    if (result == null) {
        EmptyState(Icons.Default.Description, "Rapor oluşturmak için önce bir araştırma yapın.")
        return
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Raporlama", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        InfoCard("Aktif araştırma", "${result.mode.label}: ${result.query}", Icons.Default.FactCheck)
        Button(onClick = { pdfLauncher.launch("TraceScope_${result.mode.name}_${safeName(result.query)}.pdf") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.PictureAsPdf, null); Spacer(Modifier.width(8.dp)); Text("PDF raporu kaydet")
        }
        OutlinedButton(onClick = { jsonLauncher.launch("TraceScope_${result.mode.name}_${safeName(result.query)}.json") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.DataObject, null); Spacer(Modifier.width(8.dp)); Text("JSON delil çıktısı kaydet")
        }
        Text("Rapor; sorgu, kaynak URL'leri, durum/güven sınıfları ve tespit edilen kamuya açık sinyalleri içerir.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Gizlilik ve güvenilirlik", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item { InfoCard("Geçmiş kapalı", "TraceScope v1.3.0 araştırma geçmişini otomatik olarak cihazda saklamaz. Rapor yalnızca siz dışa aktardığınızda yazılır.", Icons.Default.Lock) }
        item { InfoCard("HTTPS zorunlu", "Uygulama cleartext HTTP trafiğini kapatır. Kaynak adaptörleri HTTPS kullanır.", Icons.Default.Https) }
        item { InfoCard("Hata izolasyonu", "Bir kaynak engeller veya hata verirse diğer kaynaklar taranmaya devam eder. Sonuç, 'Hata' veya 'Tarayıcı doğrulaması' şeklinde açıkça işaretlenir.", Icons.Default.HealthAndSafety) }
        item { InfoCard("Sınırlar", "Gizli kayıt e-postası/telefonu, OTP atlatma, özel mesaj, parola, canlı konum veya erişim kontrolü aşma işlevi yoktur.", Icons.Default.Policy) }
        item { InfoCard("Sürüm", "TraceScope OSINT Pro 1.3.0", Icons.Default.Info) }
    }
}

@Composable
private fun EmptyState(icon: ImageVector, text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Icon(icon, null, modifier = Modifier.size(54.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .7f))
            Spacer(Modifier.height(12.dp))
            Text(text, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
        }
    }
}

@Composable
private fun EmptyCard(text: String) {
    OutlinedCard(Modifier.fillMaxWidth()) { Text(text, Modifier.padding(16.dp)) }
}

private fun placeholderFor(mode: SearchMode): String = when (mode) {
    SearchMode.PHONE -> "+90 5xx xxx xx xx"
    SearchMode.USERNAME -> "Kullanıcı adı"
    SearchMode.EMAIL -> "ornek@alanadi.com"
    SearchMode.CONTACT_LINK -> "Telefon numarası veya e-posta"
    SearchMode.IP -> "8.8.8.8"
}

private fun iconFor(mode: SearchMode): ImageVector = when (mode) {
    SearchMode.PHONE -> Icons.Default.Phone
    SearchMode.USERNAME -> Icons.Default.PersonSearch
    SearchMode.EMAIL -> Icons.Default.Email
    SearchMode.CONTACT_LINK -> Icons.Default.SyncAlt
    SearchMode.IP -> Icons.Default.Language
}

private fun openUrl(context: android.content.Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun btkOperatorUrl(value: String): String {
    val digits = value.filter { it.isDigit() }.let { if (it.startsWith("90") && it.length > 10) it.drop(2) else it }
    return "https://www.turkiye.gov.tr/btk-numara-tasima?asama=1&txtMsisdn=$digits"
}

private fun safeName(value: String): String = value.replace(Regex("[^a-zA-Z0-9._-]"), "_").take(40)
