package com.tracescope.osint

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tracescope.osint.engine.*
import com.tracescope.osint.model.SearchBundle
import com.tracescope.osint.model.SearchMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SearchUiState(
    val mode: SearchMode = SearchMode.USERNAME,
    val query: String = "",
    val deepScan: Boolean = true,
    val loading: Boolean = false,
    val message: String? = null,
    val result: SearchBundle? = null
)

class TraceScopeViewModel : ViewModel() {
    private val phoneEngine = PhoneEngine()
    private val usernameEngine = UsernameEngine()
    private val ipEngine = IpEngine()
    private val domainEngine = DomainEngine()

    var state = androidx.compose.runtime.mutableStateOf(SearchUiState())
        private set

    fun setMode(mode: SearchMode) { state.value = state.value.copy(mode = mode, result = null, message = null) }
    fun setQuery(value: String) { state.value = state.value.copy(query = value) }
    fun setDeepScan(value: Boolean) { state.value = state.value.copy(deepScan = value) }

    fun search() {
        val s = state.value
        if (s.query.isBlank()) {
            state.value = s.copy(message = "Aranacak değeri girin")
            return
        }
        state.value = s.copy(loading = true, message = null, result = null)
        viewModelScope.launch {
            val base = try {
                when (s.mode) {
                    SearchMode.PHONE -> withContext(Dispatchers.Default) {
                        val phone = phoneEngine.analyze(s.query)
                        val contact = ContactCorrelationEngine.analyze(s.query)
                        SearchBundle(s.mode, s.query, phone = phone, contact = contact)
                    }
                    SearchMode.USERNAME -> {
                        val username = usernameEngine.analyze(s.query, s.deepScan)
                        SearchBundle(s.mode, s.query, username = username)
                    }
                    SearchMode.EMAIL -> {
                        val email = withContext(Dispatchers.Default) { EmailEngine.analyze(s.query) }
                        val contact = withContext(Dispatchers.Default) { ContactCorrelationEngine.analyze(s.query) }
                        val username = if (email.valid && email.usernameCandidates.isNotEmpty()) {
                            usernameEngine.analyzeCandidates(email.usernameCandidates.take(if (s.deepScan) 3 else 1), s.deepScan)
                        } else null
                        val domain = if (email.valid && email.domain.isNotBlank()) {
                            withContext(Dispatchers.IO) { domainEngine.analyze(email.domain) }
                        } else null
                        SearchBundle(s.mode, s.query, email = email, contact = contact, username = username, domain = domain)
                    }
                    SearchMode.CONTACT_LINK -> {
                        val contact = withContext(Dispatchers.Default) { ContactCorrelationEngine.analyze(s.query) }
                        if ('@' in s.query) {
                            val email = withContext(Dispatchers.Default) { EmailEngine.analyze(s.query) }
                            val username = if (email.valid && email.usernameCandidates.isNotEmpty()) {
                                usernameEngine.analyzeCandidates(email.usernameCandidates.take(if (s.deepScan) 3 else 1), s.deepScan)
                            } else null
                            val domain = if (email.valid && email.domain.isNotBlank()) {
                                withContext(Dispatchers.IO) { domainEngine.analyze(email.domain) }
                            } else null
                            SearchBundle(s.mode, s.query, email = email, contact = contact, username = username, domain = domain)
                        } else {
                            val phone = withContext(Dispatchers.Default) { phoneEngine.analyze(s.query) }
                            SearchBundle(s.mode, s.query, phone = phone, contact = contact)
                        }
                    }
                    SearchMode.IP -> withContext(Dispatchers.IO) {
                        SearchBundle(s.mode, s.query, ip = ipEngine.analyze(s.query))
                    }
                }
            } catch (t: Throwable) {
                state.value = state.value.copy(message = "Araştırma hatası: ${t.message ?: t.javaClass.simpleName}")
                null
            }

            val result = base?.copy(person = PersonEvidenceEngine.summarize(base.username, base.email, base.phone))
            state.value = if (result == null) {
                state.value.copy(loading = false, message = state.value.message ?: "Araştırma tamamlanamadı. İnternet bağlantısını kontrol edin.")
            } else {
                state.value.copy(loading = false, result = result)
            }
        }
    }
}
