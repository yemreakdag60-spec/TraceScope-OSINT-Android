package com.tracescope.osint.engine

import com.tracescope.osint.model.*
import com.google.i18n.phonenumbers.PhoneNumberToCarrierMapper
import com.google.i18n.phonenumbers.PhoneNumberToTimeZonesMapper
import com.google.i18n.phonenumbers.PhoneNumberUtil
import com.google.i18n.phonenumbers.geocoding.PhoneNumberOfflineGeocoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.net.URI
import java.net.InetAddress
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.system.measureTimeMillis

class NetworkClient {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .callTimeout(14, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    data class FetchResult(
        val code: Int?,
        val body: String,
        val finalUrl: String,
        val latencyMs: Long,
        val error: String? = null
    )

    fun get(url: String): FetchResult {
        if (!SafePublicUrl.isAllowed(url)) {
            return FetchResult(null, "", url, 0, "Güvenli olmayan/yerel URL engellendi")
        }
        var result: FetchResult? = null
        val elapsed = measureTimeMillis {
            try {
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/131 Mobile Safari/537.36 TraceScopeOSINT/1.3")
                    .header("Accept-Language", "tr-TR,tr;q=0.9,en;q=0.7")
                    .get()
                    .build()
                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty().take(350_000)
                    result = FetchResult(response.code, text, response.request.url.toString(), 0)
                }
            } catch (t: Throwable) {
                result = FetchResult(null, "", url, 0, t.message ?: t.javaClass.simpleName)
            }
        }
        return result!!.copy(latencyMs = elapsed)
    }
}

object SourceRegistry {
    val sources = listOf(
        PlatformSource("GitHub", "https://github.com/%s", true, listOf("Page not found · GitHub")),
        PlatformSource("GitLab", "https://gitlab.com/%s", true, listOf("The page could not be found")),
        PlatformSource("Keybase", "https://keybase.io/%s", true, listOf("User not found")),
        PlatformSource("DEV", "https://dev.to/%s", true, listOf("Page not found")),
        PlatformSource("Medium", "https://medium.com/@%s", false, listOf("PAGE NOT FOUND", "Page not found")),
        PlatformSource("Reddit", "https://www.reddit.com/user/%s/", false, listOf("page not found", "Sorry, nobody on Reddit goes by that name")),
        PlatformSource("Telegram", "https://t.me/%s", false, emptyList()),
        PlatformSource("Instagram", "https://www.instagram.com/%s/", false, listOf("Sorry, this page isn't available", "Page Not Found")),
        PlatformSource("Facebook", "https://www.facebook.com/%s", false, listOf("This content isn't available", "Page not found", "The link you followed may be broken")),
        PlatformSource("X", "https://x.com/%s", false, listOf("This account doesn’t exist", "Account suspended")),
        PlatformSource("TikTok", "https://www.tiktok.com/@%s", false, listOf("Couldn't find this account", "Page not available")),
        PlatformSource("YouTube", "https://www.youtube.com/@%s", false, listOf("404 Not Found", "This page isn't available")),
        PlatformSource("Twitch", "https://www.twitch.tv/%s", false, listOf("Sorry. Unless you’ve got a time machine")),
        PlatformSource("Pinterest", "https://www.pinterest.com/%s/", false, listOf("Sorry, we couldn't find that page")),
        PlatformSource("SoundCloud", "https://soundcloud.com/%s", false, listOf("We can’t find that user")),
        PlatformSource("Vimeo", "https://vimeo.com/%s", false, listOf("Sorry, we couldn’t find that page")),
        PlatformSource("LinkedIn", "https://www.linkedin.com/in/%s", false, listOf("Page not found", "This page doesn’t exist")),
        PlatformSource("Threads", "https://www.threads.net/@%s", false, listOf("Page not found", "Sorry, this page isn't available")),
        PlatformSource("Snapchat", "https://www.snapchat.com/add/%s", false, listOf("Page not found", "couldn't find")),
        PlatformSource("Steam", "https://steamcommunity.com/id/%s", false, listOf("The specified profile could not be found")),
        PlatformSource("Behance", "https://www.behance.net/%s", false, listOf("Page Not Found")),
        PlatformSource("Flickr", "https://www.flickr.com/people/%s/", false, listOf("Page Not Found")),
        PlatformSource("Tumblr", "https://%s.tumblr.com", false, listOf("There's nothing here")),
        PlatformSource("Ko-fi", "https://ko-fi.com/%s", false, listOf("Page not found")),
        PlatformSource("Patreon", "https://www.patreon.com/%s", false, listOf("Page not found"))
    )
}

class PhoneEngine {
    private val util = PhoneNumberUtil.getInstance()
    private val carrierMapper = PhoneNumberToCarrierMapper.getInstance()
    private val geocoder = PhoneNumberOfflineGeocoder.getInstance()
    private val tzMapper = PhoneNumberToTimeZonesMapper.getInstance()

    fun analyze(input: String, defaultRegion: String = "TR"): PhoneIntel {
        return try {
            val number = util.parse(input.trim(), defaultRegion)
            val locale = Locale("tr", "TR")
            PhoneIntel(
                input = input,
                valid = util.isValidNumber(number),
                possible = util.isPossibleNumber(number),
                international = util.format(number, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL),
                national = util.format(number, PhoneNumberUtil.PhoneNumberFormat.NATIONAL),
                e164 = util.format(number, PhoneNumberUtil.PhoneNumberFormat.E164),
                regionCode = util.getRegionCodeForNumber(number).orEmpty(),
                countryCode = number.countryCode,
                type = when (util.getNumberType(number)) {
                    PhoneNumberUtil.PhoneNumberType.MOBILE -> "Mobil"
                    PhoneNumberUtil.PhoneNumberType.FIXED_LINE -> "Sabit hat"
                    PhoneNumberUtil.PhoneNumberType.FIXED_LINE_OR_MOBILE -> "Sabit/Mobil"
                    PhoneNumberUtil.PhoneNumberType.TOLL_FREE -> "Ücretsiz hat"
                    PhoneNumberUtil.PhoneNumberType.PREMIUM_RATE -> "Premium"
                    PhoneNumberUtil.PhoneNumberType.VOIP -> "VoIP"
                    PhoneNumberUtil.PhoneNumberType.PAGER -> "Pager"
                    PhoneNumberUtil.PhoneNumberType.PERSONAL_NUMBER -> "Kişisel numara"
                    else -> "Bilinmiyor"
                },
                carrier = carrierMapper.getNameForNumber(number, locale).orEmpty(),
                geographicDescription = geocoder.getDescriptionForNumber(number, locale).orEmpty(),
                timeZones = tzMapper.getTimeZonesForNumber(number).toList(),
                webPivots = buildPhonePivots(
                    util.format(number, PhoneNumberUtil.PhoneNumberFormat.E164),
                    util.format(number, PhoneNumberUtil.PhoneNumberFormat.NATIONAL),
                    util.format(number, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL)
                ),
                operatorVerificationUrl = if (util.getRegionCodeForNumber(number) == "TR") {
                    val msisdn = util.format(number, PhoneNumberUtil.PhoneNumberFormat.NATIONAL).filter(Char::isDigit)
                    "https://www.turkiye.gov.tr/btk-numara-tasima?txtMsisdn=$msisdn"
                } else ""
            )
        } catch (t: Throwable) {
            PhoneIntel(input = input, valid = false, possible = false, error = t.message ?: "Numara çözümlenemedi")
        }
    }

    private fun buildPhonePivots(e164: String, national: String, international: String): List<Pair<String, String>> {
        fun enc(v: String) = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
        val exact = listOf(e164, national, international).filter { it.isNotBlank() }.distinct()
        val ors = exact.joinToString(" OR ") { "\"$it\"" }
        return listOf(
            "Google exact" to "https://www.google.com/search?q=${enc(ors)}",
            "Bing exact" to "https://www.bing.com/search?q=${enc(ors)}",
            "Sosyal profil izi" to "https://www.google.com/search?q=${enc("($ors) (site:instagram.com OR site:x.com OR site:facebook.com OR site:tiktok.com)")}",
            "Web iletişim izi" to "https://www.google.com/search?q=${enc("($ors) (contact OR iletişim OR whatsapp)")}"
        )
    }
}

object EmailEngine {
    private val emailRegex = Regex("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}$", RegexOption.IGNORE_CASE)

    fun analyze(input: String): EmailIntel {
        val email = input.trim().lowercase()
        if (!emailRegex.matches(email)) return EmailIntel(input, false, error = "Geçerli bir e-posta biçimi girin")
        val local = email.substringBefore('@')
        val domain = email.substringAfter('@')
        val quoted = urlEncode("\"$email\"")
        val usernames = UsernameVariantGenerator.generate(local, limit = 14)
        val tokens = local
            .replace(Regex("[0-9]+"), " ")
            .split('.', '_', '-', '+')
            .map { it.trim() }
            .filter { it.length >= 2 }
            .distinct()
            .take(6)
        val handleTerms = usernames.take(8).joinToString(" OR ") { "\"$it\"" }
        val tokenTerms = tokens.joinToString(" OR ") { "\"$it\"" }
        val provider = when (domain) {
            "gmail.com", "googlemail.com" -> "Google / Gmail"
            "hotmail.com", "outlook.com", "live.com", "msn.com" -> "Microsoft / Outlook"
            "yahoo.com", "yahoo.com.tr" -> "Yahoo"
            "proton.me", "protonmail.com" -> "Proton"
            "icloud.com", "me.com", "mac.com" -> "Apple / iCloud"
            else -> "Özel/kurumsal alan adı"
        }
        val pivots = listOf(
            "Exact e-posta" to "https://www.google.com/search?q=$quoted",
            "Exact e-posta + telefon" to "https://www.google.com/search?q=${urlEncode("\"$email\" (telefon OR phone OR mobile OR gsm OR whatsapp OR iletişim OR contact)")}",
            "Exact e-posta + ad/soyad" to "https://www.google.com/search?q=${urlEncode("\"$email\" (name OR fullname OR ad OR soyad OR profile OR profil)")}",
            "Exact e-posta + konum" to "https://www.google.com/search?q=${urlEncode("\"$email\" (location OR city OR address OR konum OR şehir OR adres)")}",
            "Sosyal medya izi" to "https://www.google.com/search?q=${urlEncode("\"$email\" (site:instagram.com OR site:facebook.com OR site:x.com OR site:tiktok.com OR site:linkedin.com OR site:github.com OR site:threads.net OR site:t.me)")}",
            "Kullanıcı adı varyasyonları" to "https://www.google.com/search?q=${urlEncode("($handleTerms) (profile OR profil OR contact OR iletişim)")}",
            "Ad parçaları + sosyal" to "https://www.google.com/search?q=${urlEncode("($tokenTerms) (site:instagram.com OR site:facebook.com OR site:x.com OR site:tiktok.com OR site:linkedin.com)")}",
            "Bing exact" to "https://www.bing.com/search?q=$quoted",
            "DuckDuckGo exact" to "https://duckduckgo.com/?q=$quoted",
            "GitHub izi" to "https://www.google.com/search?q=${urlEncode("site:github.com \"$email\"")}"
        )
        val domainPivots = listOf(
            "Alan adı ana sayfası" to "https://$domain",
            "Alan adı iletişim/ekip" to "https://www.google.com/search?q=${urlEncode("site:$domain (contact OR iletişim OR team OR staff OR ekip)")}",
            "Alan adı + e-posta" to "https://www.google.com/search?q=${urlEncode("site:$domain \"$email\"")}",
            "Alan adı sosyal hesapları" to "https://www.google.com/search?q=${urlEncode("\"$domain\" (site:linkedin.com OR site:facebook.com OR site:instagram.com OR site:x.com)")}"
        )
        return EmailIntel(
            input = input,
            valid = true,
            localPart = local,
            domain = domain,
            providerLabel = provider,
            usernameCandidates = usernames,
            identityTokens = tokens,
            webPivots = pivots,
            domainPivots = domainPivots
        )
    }

    private fun urlEncode(v: String): String = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
}

class IpEngine(private val network: NetworkClient = NetworkClient()) {
    fun analyze(input: String): IpIntel {
        val ip = input.trim()
        if (!ip.matches(Regex("^[0-9a-fA-F:.]{3,45}$"))) return IpIntel(input, false, note = "IP biçimi geçersiz")
        val fetch = network.get("https://ipwho.is/${urlEncode(ip)}")
        if (fetch.error != null || fetch.code !in 200..299) return IpIntel(input, false, note = fetch.error ?: "Servis yanıt vermedi")
        return try {
            val o = JSONObject(fetch.body)
            if (!o.optBoolean("success", true)) return IpIntel(input, false, note = o.optString("message", "IP bulunamadı"))
            val conn = o.optJSONObject("connection")
            IpIntel(
                input = input,
                success = true,
                ip = o.optString("ip", ip),
                country = o.optString("country"),
                region = o.optString("region"),
                city = o.optString("city"),
                isp = conn?.optString("isp").orEmpty(),
                asn = conn?.optString("asn").orEmpty(),
                latitude = if (o.has("latitude")) o.optDouble("latitude") else null,
                longitude = if (o.has("longitude")) o.optDouble("longitude") else null,
                note = "IP konumu yaklaşık ağ konumudur; canlı GPS değildir."
            )
        } catch (t: Throwable) {
            IpIntel(input, false, note = "Yanıt çözümlenemedi: ${t.message}")
        }
    }

    private fun urlEncode(v: String): String = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
}

class UsernameEngine(private val network: NetworkClient = NetworkClient()) {
    suspend fun analyze(input: String, deepScan: Boolean = true): UsernameIntel = coroutineScope {
        val firstVariants = UsernameVariantGenerator.generate(input, limit = if (deepScan) 14 else 1)
        val exact = firstVariants.firstOrNull()?.let { listOf(it) }.orEmpty()
        val primary = probeVariants(exact, SourceRegistry.sources)

        val discoveredNames = primary.mapNotNull { it.clues.displayName }.distinct().take(3)
        val allVariants = if (deepScan) UsernameVariantGenerator.generate(input, discoveredNames, limit = 20) else firstVariants
        val extraVariants = allVariants.drop(1).take(6)
        val highYield = SourceRegistry.sources.filter { it.name in setOf(
            "GitHub", "GitLab", "Keybase", "DEV", "Medium", "Reddit", "Telegram",
            "Instagram", "Facebook", "X", "TikTok", "YouTube", "Threads", "LinkedIn"
        ) }
        val extra = if (deepScan && extraVariants.isNotEmpty()) probeVariants(extraVariants, highYield) else emptyList()
        val profiles = (primary + extra)
            .distinctBy { "${it.source.name}|${it.username}" }
            .sortedWith(compareBy<ProfileHit>({ stateRank(it.state) }, { it.confidence.ordinal }, { it.source.name }))

        val clean = input.trim().removePrefix("@")
        val encoded = URLEncoder.encode(clean, StandardCharsets.UTF_8.toString())
        val contactQuery = URLEncoder.encode("\"$clean\" (email OR e-posta OR telefon OR phone OR gsm OR whatsapp OR contact OR iletişim)", StandardCharsets.UTF_8.toString())
        val socialQuery = URLEncoder.encode("\"$clean\" (site:instagram.com OR site:facebook.com OR site:x.com OR site:tiktok.com OR site:linkedin.com OR site:github.com)", StandardCharsets.UTF_8.toString())
        val webPivots = listOf(
            "Google exact kullanıcı adı" to "https://www.google.com/search?q=%22$encoded%22",
            "Açık iletişim izi" to "https://www.google.com/search?q=$contactQuery",
            "Sosyal profil web izi" to "https://www.google.com/search?q=$socialQuery",
            "Bing kullanıcı adı" to "https://www.bing.com/search?q=$encoded",
            "DuckDuckGo kullanıcı adı" to "https://duckduckgo.com/?q=$encoded"
        )

        val linkedSites = profiles.flatMap { it.clues.websites }
            .filter { SafePublicUrl.isAllowed(it) }
            .distinct()
            .take(if (deepScan) 4 else 1)
        val websiteEvidence = PublicWebsiteEnricher(network).enrich(linkedSites)

        UsernameIntel(
            input = input,
            variants = allVariants,
            profiles = profiles,
            publicEmails = (profiles.flatMap { it.clues.emails } + websiteEvidence.flatMap { it.emails }).map { it.lowercase() }.distinct(),
            publicPhones = (profiles.flatMap { it.clues.phones } + websiteEvidence.flatMap { it.phones }).distinct(),
            locationSignals = (profiles.flatMap { it.clues.locations } + websiteEvidence.flatMap { it.locations }).distinct(),
            websites = (profiles.flatMap { it.clues.websites } + websiteEvidence.map { it.url }).distinct(),
            displayNames = profiles.mapNotNull { it.clues.displayName }.distinct(),
            webPivots = webPivots,
            websiteEvidence = websiteEvidence,
            sourcesAttempted = profiles.size
        )
    }

    suspend fun analyzeCandidates(candidates: List<String>, deepScan: Boolean = true): UsernameIntel {
        val clean = candidates.map { it.trim().removePrefix("@") }.filter { it.isNotBlank() }.distinct().take(3)
        if (clean.isEmpty()) return analyze("", false)
        val results = mutableListOf<UsernameIntel>()
        clean.forEachIndexed { index, candidate ->
            results += analyze(candidate, deepScan = deepScan && index == 0)
        }
        return UsernameIntel(
            input = clean.joinToString(" | "),
            variants = results.flatMap { it.variants }.distinct().take(30),
            profiles = results.flatMap { it.profiles }
                .distinctBy { "${it.source.name}|${it.username}" }
                .sortedWith(compareBy<ProfileHit>({ stateRank(it.state) }, { it.confidence.ordinal }, { it.source.name })),
            publicEmails = results.flatMap { it.publicEmails }.distinct(),
            publicPhones = results.flatMap { it.publicPhones }.distinct(),
            locationSignals = results.flatMap { it.locationSignals }.distinct(),
            websites = results.flatMap { it.websites }.distinct(),
            displayNames = results.flatMap { it.displayNames }.distinct(),
            webPivots = results.flatMap { it.webPivots }.distinctBy { it.second },
            websiteEvidence = results.flatMap { it.websiteEvidence }.distinctBy { it.url },
            sourcesAttempted = results.sumOf { it.sourcesAttempted }
        )
    }

    private suspend fun probeVariants(variants: List<String>, sources: List<PlatformSource>): List<ProfileHit> = coroutineScope {
        val semaphore = Semaphore(5)
        val jobs = variants.flatMap { username ->
            sources.map { source -> async(Dispatchers.IO) { semaphore.withPermit { probe(source, username) } } }
        }
        jobs.awaitAll()
    }

    private fun probe(source: PlatformSource, username: String): ProfileHit {
        val url = source.urlTemplate.format(username)
        val result = network.get(url)
        if (result.error != null) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.ERROR, Confidence.UNKNOWN, result.code, result.latencyMs, result.error)
        }
        val code = result.code ?: 0
        if (code == 404 || code == 410) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.NOT_FOUND, Confidence.HIGH, code, result.latencyMs, "Bulunamadı")
        }
        if (code == 401 || code == 403 || code == 429) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.BLOCKED, Confidence.UNKNOWN, code, result.latencyMs, "Kaynak otomatik isteği sınırladı; tarayıcıda doğrulanabilir")
        }
        if (code !in 200..399) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.ERROR, Confidence.UNKNOWN, code, result.latencyMs, "HTTP $code")
        }
        val bodyLower = result.body.lowercase()
        val missing = source.notFoundMarkers.any { marker -> bodyLower.contains(marker.lowercase()) }
        if (missing) {
            return ProfileHit(source, username, url, result.finalUrl, ProbeState.NOT_FOUND, Confidence.HIGH, code, result.latencyMs, "Sayfa yok işareti tespit edildi")
        }

        val clues = PublicIntelExtractor.extract(result.body, result.finalUrl)
        val evidenceMatches = listOfNotNull(clues.displayName, clues.description)
            .joinToString(" ")
            .lowercase()
            .contains(username.lowercase())

        val state = when {
            source.reliableHttp200 && code in 200..299 -> ProbeState.CONFIRMED
            evidenceMatches && code in 200..299 -> ProbeState.LIKELY
            else -> ProbeState.AMBIGUOUS
        }
        val confidence = when (state) {
            ProbeState.CONFIRMED -> Confidence.HIGH
            ProbeState.LIKELY -> Confidence.MEDIUM
            ProbeState.AMBIGUOUS -> Confidence.LOW
            else -> Confidence.UNKNOWN
        }
        val note = when (state) {
            ProbeState.CONFIRMED -> "Kaynakta profil yanıtı doğrulandı"
            ProbeState.LIKELY -> "Profil sinyali bulundu; içerik ile desteklendi"
            ProbeState.AMBIGUOUS -> "HTTP yanıtı var ancak hesap varlığı kesin doğrulanamadı"
            else -> ""
        }
        return ProfileHit(source, username, url, result.finalUrl, state, confidence, code, result.latencyMs, note, clues)
    }

    private fun stateRank(state: ProbeState): Int = when (state) {
        ProbeState.CONFIRMED -> 0
        ProbeState.LIKELY -> 1
        ProbeState.AMBIGUOUS -> 2
        ProbeState.BLOCKED -> 3
        ProbeState.NOT_FOUND -> 4
        ProbeState.ERROR -> 5
    }
}

object SafePublicUrl {
    fun isAllowed(url: String): Boolean {
        return try {
            val uri = URI(url)
            if (uri.scheme?.lowercase() !in setOf("http", "https")) return false
            val host = uri.host?.lowercase()?.trim('.').orEmpty()
            if (host.isBlank() || host == "localhost" || host.endsWith(".local")) return false
            if (host == "0.0.0.0" || host == "::1") return false
            val literal = runCatching { InetAddress.getByName(host) }.getOrNull()
            if (literal != null && (literal.isAnyLocalAddress || literal.isLoopbackAddress || literal.isLinkLocalAddress || literal.isSiteLocalAddress)) return false
            true
        } catch (_: Throwable) { false }
    }
}

class PublicWebsiteEnricher(private val network: NetworkClient = NetworkClient()) {
    suspend fun enrich(urls: List<String>): List<WebsiteEvidence> = coroutineScope {
        urls.distinct().take(4).map { raw ->
            async(Dispatchers.IO) { enrichOne(raw) }
        }.awaitAll().filterNotNull()
    }

    private fun enrichOne(raw: String): WebsiteEvidence? {
        val base = normalize(raw) ?: return null
        if (!SafePublicUrl.isAllowed(base)) return null
        val first = network.get(base)
        if (first.error != null || first.code !in 200..399) {
            return WebsiteEvidence(base, status = first.error ?: "HTTP ${first.code}", latencyMs = first.latencyMs)
        }
        val clues = mutableListOf(PublicIntelExtractor.extract(first.body, first.finalUrl))
        val related = PublicIntelExtractor.contactLinks(first.body, first.finalUrl).take(2)
        related.forEach { link ->
            if (SafePublicUrl.isAllowed(link)) {
                val r = network.get(link)
                if (r.error == null && r.code in 200..399) clues += PublicIntelExtractor.extract(r.body, r.finalUrl)
            }
        }
        return WebsiteEvidence(
            url = first.finalUrl,
            pageTitle = clues.firstOrNull()?.displayName.orEmpty(),
            emails = clues.flatMap { it.emails }.distinct().take(12),
            phones = clues.flatMap { it.phones }.distinct().take(12),
            locations = clues.flatMap { it.locations }.distinct().take(12),
            socialLinks = clues.flatMap { it.websites }.filter { isSocial(it) }.distinct().take(16),
            status = "Açık web zenginleştirme tamamlandı",
            latencyMs = first.latencyMs
        )
    }

    private fun normalize(raw: String): String? = runCatching {
        val u = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
        val uri = URI(u)
        if (uri.host.isNullOrBlank()) null else u
    }.getOrNull()

    private fun isSocial(url: String): Boolean {
        val h = runCatching { URI(url).host.orEmpty().lowercase() }.getOrDefault("")
        return listOf("instagram.com","facebook.com","x.com","twitter.com","tiktok.com","linkedin.com","threads.net","t.me","github.com","youtube.com").any { h == it || h.endsWith(".$it") }
    }
}

class DomainEngine(private val network: NetworkClient = NetworkClient()) {
    fun analyze(domainInput: String): DomainIntel {
        val domain = domainInput.trim().lowercase().removePrefix("www.")
        if (!domain.matches(Regex("^[a-z0-9.-]+\\.[a-z]{2,63}$"))) return DomainIntel(domain, error = "Alan adı biçimi geçersiz")
        return try {
            val mx = dns(domain, "MX").map { it.substringAfter(' ').trimEnd('.') }.distinct()
            val txt = dns(domain, "TXT")
            val spf = txt.filter { it.contains("v=spf1", ignoreCase = true) }
            val dmarc = dns("_dmarc.$domain", "TXT").filter { it.contains("v=DMARC1", ignoreCase = true) }
            DomainIntel(
                domain = domain,
                mxHosts = mx,
                spfRecords = spf,
                dmarcRecords = dmarc,
                rdapLookupUrl = "https://rdap.org/domain/${URLEncoder.encode(domain, StandardCharsets.UTF_8.toString())}",
                notes = buildList {
                    if (mx.isEmpty()) add("MX kaydı bulunamadı veya DNS servisi yanıt vermedi")
                    if (spf.isEmpty()) add("SPF kaydı görünmedi")
                    if (dmarc.isEmpty()) add("DMARC kaydı görünmedi")
                }
            )
        } catch (t: Throwable) {
            DomainIntel(domain, error = t.message ?: "Alan adı analizi başarısız")
        }
    }

    private fun dns(name: String, type: String): List<String> {
        val url = "https://dns.google/resolve?name=${URLEncoder.encode(name, StandardCharsets.UTF_8.toString())}&type=$type"
        val result = network.get(url)
        if (result.error != null || result.code !in 200..299) return emptyList()
        val root = JSONObject(result.body)
        val arr = root.optJSONArray("Answer") ?: return emptyList()
        return buildList {
            for (i in 0 until arr.length()) {
                val data = arr.optJSONObject(i)?.optString("data").orEmpty().trim('"')
                if (data.isNotBlank()) add(data)
            }
        }
    }
}

object PublicIntelExtractor {
    private val emailRegex = Regex("[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}", RegexOption.IGNORE_CASE)
    private val metaTitle = Regex("(?is)<meta[^>]+(?:property|name)=[\"']og:title[\"'][^>]+content=[\"']([^\"']+)[\"']")
    private val metaDesc = Regex("(?is)<meta[^>]+(?:property|name)=[\"'](?:og:description|description)[\"'][^>]+content=[\"']([^\"']+)[\"']")
    private val canonical = Regex("(?is)<link[^>]+rel=[\"']canonical[\"'][^>]+href=[\"']([^\"']+)[\"']")
    private val titleTag = Regex("(?is)<title[^>]*>(.*?)</title>")
    private val locationJson = Regex("(?i)\"(?:location|addressLocality|addressRegion|addressCountry)\"\\s*:\\s*\"([^\"]{2,100})\"")
    private val homeLocationTitle = Regex("(?is)itemprop=[\"']homeLocation[\"'][^>]*title=[\"']([^\"']{2,100})[\"']")
    private val hrefRegex = Regex("(?is)href=[\"'](https?://[^\"'# ]+)[\"']")
    private val mailtoRegex = Regex("(?is)href=[\"']mailto:([^?\"']+)")
    private val telRegex = Regex("(?is)href=[\"']tel:([^?\"']+)")
    private val jsonEmailRegex = Regex("(?i)\"email\"\\s*:\\s*\"([^\"]+)\"")
    private val jsonPhoneRegex = Regex("(?i)\"telephone\"\\s*:\\s*\"([^\"]+)\"")
    private val sameAsRegex = Regex("(?is)\"sameAs\"\\s*:\\s*\\[(.*?)\\]")
    private val quotedUrlRegex = Regex("https?://[^\"'\\s,]+")

    fun extract(html: String, finalUrl: String): PublicClues {
        if (html.isBlank()) return PublicClues()
        val displayName = decode(metaTitle.find(html)?.groupValues?.getOrNull(1)
            ?: titleTag.find(html)?.groupValues?.getOrNull(1)).takeIf { it.isNotBlank() }
        val description = decode(metaDesc.find(html)?.groupValues?.getOrNull(1)).takeIf { it.isNotBlank() }
        val stripped = stripTags(html).take(120_000)

        val emails = buildList {
            emailRegex.findAll("$description $stripped").map { it.value.lowercase() }.forEach(::add)
            mailtoRegex.findAll(html).map { decode(it.groupValues[1]).lowercase() }.forEach(::add)
            jsonEmailRegex.findAll(html).map { decode(it.groupValues[1]).lowercase() }.forEach(::add)
        }.filter { emailRegex.matches(it) }
            .filterNot { email ->
                email.endsWith("@example.com") || email.contains("sentry") ||
                    email.substringBefore('@') in setOf("support", "help", "privacy", "security", "noreply", "no-reply")
            }
            .distinct().take(10)

        val phones = buildList {
            val util = PhoneNumberUtil.getInstance()
            runCatching {
                util.findNumbers("$description $stripped", "ZZ")
                    .map { util.format(it.number(), PhoneNumberUtil.PhoneNumberFormat.E164) }
                    .forEach(::add)
            }
            val rawPhoneCandidates = buildList {
                telRegex.findAll(html).map { decode(it.groupValues[1]) }.forEach(::add)
                jsonPhoneRegex.findAll(html).map { decode(it.groupValues[1]) }.forEach(::add)
            }
            rawPhoneCandidates.forEach { raw ->
                val region = if (raw.trim().startsWith("0")) "TR" else "ZZ"
                runCatching {
                    val parsed = util.parse(raw, region)
                    if (util.isPossibleNumber(parsed)) add(util.format(parsed, PhoneNumberUtil.PhoneNumberFormat.E164))
                }
            }
        }.filter { it.length in 8..16 }.distinct().take(10)

        val locations = buildList {
            locationJson.findAll(html).map { decode(it.groupValues[1]) }.filter { it.length in 2..100 }.take(8).forEach(::add)
            homeLocationTitle.findAll(html).map { decode(it.groupValues[1]) }.filter { it.length in 2..100 }.take(4).forEach(::add)
        }.distinct()

        val websites = buildList {
            canonical.find(html)?.groupValues?.getOrNull(1)?.let { add(decode(it)) }
            hrefRegex.findAll(html).map { decode(it.groupValues[1]) }
                .filterNot { it.contains("${host(finalUrl)}/") || it.contains("google.com") }
                .take(12).forEach(::add)
            sameAsRegex.findAll(html).flatMap { quotedUrlRegex.findAll(it.groupValues[1]).map { m -> decode(m.value) } }
                .take(12).forEach(::add)
        }.distinct().take(16)

        return PublicClues(displayName, description, emails, phones, locations, websites)
    }

    fun contactLinks(html: String, baseUrl: String): List<String> {
        val base = runCatching { URI(baseUrl) }.getOrNull() ?: return emptyList()
        val relativeHref = Regex("(?is)href=[\"']([^\"'#]+)[\"']")
        val keywords = listOf("contact", "iletisim", "iletişim", "about", "hakkimizda", "hakkımızda", "team", "ekip")
        return relativeHref.findAll(html).mapNotNull { m ->
            val href = decode(m.groupValues[1]).trim()
            if (href.startsWith("mailto:") || href.startsWith("tel:")) return@mapNotNull null
            val absolute = runCatching { base.resolve(href).toString() }.getOrNull() ?: return@mapNotNull null
            val sameHost = runCatching { URI(absolute).host.equals(base.host, ignoreCase = true) }.getOrDefault(false)
            if (sameHost && keywords.any { absolute.lowercase().contains(it) }) absolute else null
        }.distinct().take(4).toList()
    }

    private fun host(url: String): String = url.removePrefix("https://").removePrefix("http://").substringBefore('/')
    private fun stripTags(value: String): String = value
        .replace(Regex("(?is)<script.*?</script>"), " ")
        .replace(Regex("(?is)<style.*?</style>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
        .replace(Regex("\\s+"), " ")

    private fun decode(value: String?): String = value.orEmpty()
        .replace("&amp;", "&").replace("&quot;", "\"")
        .replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")
        .trim()
}
