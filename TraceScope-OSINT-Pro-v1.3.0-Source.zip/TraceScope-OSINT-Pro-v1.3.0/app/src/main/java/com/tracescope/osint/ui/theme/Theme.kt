package com.tracescope.osint.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF2BCBFF),
    onPrimary = Color(0xFF001A24),
    primaryContainer = Color(0xFF063A52),
    onPrimaryContainer = Color(0xFFBCEBFF),
    secondary = Color(0xFF9A7BFF),
    onSecondary = Color(0xFF18005F),
    secondaryContainer = Color(0xFF2D2456),
    tertiary = Color(0xFF39DFA2),
    background = Color(0xFF050D16),
    surface = Color(0xFF0A1622),
    surfaceVariant = Color(0xFF102235),
    surfaceContainer = Color(0xFF0D1B29),
    surfaceContainerHigh = Color(0xFF132638),
    onBackground = Color(0xFFE9F5FF),
    onSurface = Color(0xFFE9F5FF),
    onSurfaceVariant = Color(0xFFB4C8D8),
    outline = Color(0xFF31506A),
    outlineVariant = Color(0xFF1E374C),
    error = Color(0xFFFF6B7A)
)

@Composable
fun TraceScopeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = Typography(),
        content = content
    )
}
