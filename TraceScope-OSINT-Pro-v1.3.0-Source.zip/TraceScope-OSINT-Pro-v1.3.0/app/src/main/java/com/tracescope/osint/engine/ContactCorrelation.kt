package com.tracescope.osint.engine

import com.tracescope.osint.model.*
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

/**
 * Public-source contact correlation helper.
 *
 * The engine never attempts to reveal private account-registration data. It normalizes
 * the supplied identifier and creates reproducible public-web pivots that can surface
 * pages where identifiers were voluntarily published together.
 */
object ContactCorrelationEngine {
    fun analyze(input: String): ContactCorrelationIntel {
        val raw = input.trim()
        if (raw.isBlank()) {
            return ContactCorrelationIntel(
                input = input,
                direction = ContactDirection.EMAIL_TO_PHONE,
                normalizedInput = "",
                error = "Telefon numarası veya e-posta girin"
            )
        }
        return if ('@' in raw) emailToPhone(raw) else phoneToEmail(raw)
    }

    private fun emailToPhone(emailInput: String): ContactCorrelationIntel {
        val email = EmailEngine.analyze(emailInput)
        if (!email.valid) {
            return ContactCorrelationIntel(
                input = emailInput,
                direction = ContactDirection.EMAIL_TO_PHONE,
                normalizedInput = emailInput.trim(),
                error = email.error ?: "Geçersiz e-posta"
            )
        }

        val emailAddress = emailInput.trim().lowercase()
        val provider = providerLabel(email.domain)
        val candidates = email.usernameCandidates.take(8)
        val userTerms = candidates.joinToString(" OR ") { "\"$it\"" }
        val pivots = listOf(
            "Exact e-posta + telefon" to google("\"$emailAddress\" (phone OR telephone OR mobile OR gsm OR telefon OR iletişim OR whatsapp)"),
            "Exact e-posta + kişi adı" to google("\"$emailAddress\" (name OR fullname OR ad OR soyad OR profile OR profil)"),
            "Exact e-posta + konum" to google("\"$emailAddress\" (location OR city OR address OR konum OR şehir OR adres)"),
            "Sosyal profil izi" to google("\"$emailAddress\" (site:github.com OR site:gitlab.com OR site:facebook.com OR site:instagram.com OR site:x.com OR site:tiktok.com OR site:linkedin.com OR site:threads.net OR site:t.me)"),
            "Kullanıcı adı + iletişim" to google("($userTerms) (phone OR telefon OR gsm OR email OR e-posta OR contact OR iletişim)"),
            "Kullanıcı adı + sosyal" to google("($userTerms) (site:instagram.com OR site:facebook.com OR site:x.com OR site:tiktok.com OR site:linkedin.com OR site:github.com OR site:threads.net)"),
            "Bing exact e-posta" to bing("\"$emailAddress\" (phone OR mobile OR gsm OR telefon OR iletişim OR profile OR profil)")
        )

        return ContactCorrelationIntel(
            input = emailInput,
            direction = ContactDirection.EMAIL_TO_PHONE,
            normalizedInput = emailAddress,
            providerHint = provider,
            usernameCandidates = email.usernameCandidates,
            searchPivots = pivots,
            notes = listOf(
                "E-posta yerel parçasından türetilen ilk üç kullanıcı adı adayı sosyal platformlarda otomatik kontrol edilir.",
                "Telefon, ad, konum ve web sitesi yalnızca kamuya açık profil/sayfa içeriğinde görünüyorsa bulgu olarak gösterilir.",
                "Gmail/Outlook/Hotmail hesabının gizli kurtarma telefonu veya özel kayıt verisi açığa çıkarılmaz."
            )
        )
    }

    private fun phoneToEmail(phoneInput: String): ContactCorrelationIntel {
        val phone = PhoneEngine().analyze(phoneInput)
        if (!phone.possible && !phone.valid) {
            return ContactCorrelationIntel(
                input = phoneInput,
                direction = ContactDirection.PHONE_TO_EMAIL,
                normalizedInput = phoneInput.trim(),
                error = phone.error ?: "Geçerli/olası telefon numarası girin"
            )
        }

        val variants = listOf(phone.e164, phone.international, phone.national)
            .filter { it.isNotBlank() }.distinct()
        val exact = variants.joinToString(" OR ") { "\"$it\"" }
        val pivots = listOf(
            "Telefon + Gmail" to google("($exact) \"@gmail.com\""),
            "Telefon + Hotmail/Outlook" to google("($exact) (\"@hotmail.com\" OR \"@outlook.com\" OR \"@live.com\")"),
            "Telefon + tüm e-postalar" to google("($exact) (email OR e-posta OR eposta OR mail OR contact OR iletişim)"),
            "Telefon + kişi adı" to google("($exact) (name OR fullname OR ad OR soyad OR profile OR profil)"),
            "Sosyal profil izi" to google("($exact) (site:instagram.com OR site:facebook.com OR site:x.com OR site:tiktok.com OR site:linkedin.com OR site:github.com OR site:threads.net OR site:t.me)"),
            "İşletme/kurum izi" to google("($exact) (company OR şirket OR kurum OR firma OR contact OR iletişim)"),
            "Bing telefon + e-posta" to bing("($exact) (email OR mail OR contact OR iletişim)")
        )

        return ContactCorrelationIntel(
            input = phoneInput,
            direction = ContactDirection.PHONE_TO_EMAIL,
            normalizedInput = phone.e164.ifBlank { phoneInput.trim() },
            providerHint = phone.carrier,
            phoneVariants = variants,
            searchPivots = pivots,
            notes = listOf(
                "Numaranın farklı açık gösterim biçimleri aynı sorguda kullanılır.",
                "Bulunan e-posta/isim yalnızca kaynak sayfada açıkça yayımlanmışsa bulgu kabul edilmelidir.",
                "Numara bloğu taşıma sonrası güncel operatörü göstermeyebilir; Türkiye için resmî BTK/e-Devlet doğrulaması kullanılmalıdır."
            )
        )
    }

    private fun providerLabel(domain: String): String = when (domain.lowercase()) {
        "gmail.com", "googlemail.com" -> "Google / Gmail"
        "hotmail.com", "outlook.com", "live.com", "msn.com" -> "Microsoft / Outlook"
        "yahoo.com", "yahoo.com.tr" -> "Yahoo"
        "proton.me", "protonmail.com" -> "Proton"
        else -> if (domain.isBlank()) "" else "Özel/kurumsal alan adı: $domain"
    }

    private fun google(q: String) = "https://www.google.com/search?q=${enc(q)}"
    private fun bing(q: String) = "https://www.bing.com/search?q=${enc(q)}"
    private fun enc(v: String) = URLEncoder.encode(v, StandardCharsets.UTF_8.toString())
}

/**
 * Produces an explainable evidence-coverage score from public signals only.
 * The score is not a claim that two accounts belong to the same real-world person.
 */
object PersonEvidenceEngine {
    fun summarize(username: UsernameIntel?, email: EmailIntel?, phone: PhoneIntel?): PublicPersonSummary {
        val profiles = username?.profiles.orEmpty().filter {
            it.state == ProbeState.CONFIRMED || it.state == ProbeState.LIKELY || it.state == ProbeState.AMBIGUOUS
        }
        val names = username?.displayNames.orEmpty().filter { it.isNotBlank() }.distinct()
        val emails = buildList {
            addAll(username?.publicEmails.orEmpty())
            email?.takeIf { it.valid }?.input?.trim()?.lowercase()?.let(::add)
        }.distinct()
        val phones = buildList {
            addAll(username?.publicPhones.orEmpty())
            phone?.takeIf { it.valid }?.e164?.takeIf { it.isNotBlank() }?.let(::add)
        }.distinct()
        val locations = username?.locationSignals.orEmpty().distinct()
        val websites = username?.websites.orEmpty().distinct()
        val blocked = username?.profiles.orEmpty().count { it.state == ProbeState.BLOCKED }
        val errors = username?.profiles.orEmpty().count { it.state == ProbeState.ERROR }
        val confirmed = profiles.count { it.state == ProbeState.CONFIRMED }
        val likely = profiles.count { it.state == ProbeState.LIKELY }

        var score = 0
        val reasons = mutableListOf<String>()
        if (confirmed > 0) { score += 20; reasons += "$confirmed kaynakta profil yanıtı güçlü biçimde doğrulandı" }
        if (likely > 0) { score += 10; reasons += "$likely kaynakta destekleyici profil sinyali bulundu" }
        if (names.isNotEmpty()) { score += 10; reasons += "Görünen ad sinyali mevcut" }
        if (emails.size >= 2) { score += 20; reasons += "Birden fazla kamuya açık e-posta sinyali mevcut" }
        else if (emails.isNotEmpty()) { score += 10; reasons += "Kamuya açık e-posta sinyali mevcut" }
        if (phones.size >= 2) { score += 25; reasons += "Birden fazla kamuya açık telefon sinyali mevcut" }
        else if (phones.isNotEmpty()) { score += 15; reasons += "Kamuya açık telefon sinyali mevcut" }
        if (websites.isNotEmpty()) { score += 10; reasons += "Bağlantılı web sitesi/domain sinyali mevcut" }
        if (locations.isNotEmpty()) { score += 5; reasons += "Konum/şehir sinyali mevcut" }
        if (profiles.map { it.source.name }.distinct().size >= 3) { score += 10; reasons += "En az üç ayrı platformdan kaynak sinyali mevcut" }
        score = score.coerceAtMost(95)

        val label = when {
            score >= 75 -> "Güçlü açık-kaynak kanıt seti"
            score >= 50 -> "Orta açık-kaynak kanıt seti"
            score >= 25 -> "Sınırlı açık-kaynak kanıt seti"
            else -> "Yetersiz açık-kaynak kanıt seti"
        }

        return PublicPersonSummary(
            names = names,
            emails = emails,
            phones = phones,
            locations = locations,
            websites = websites,
            profileHits = profiles,
            evidenceScore = score,
            evidenceLabel = label,
            reasons = reasons,
            sourceCount = profiles.map { it.source.name }.distinct().size,
            blockedCount = blocked,
            errorCount = errors
        )
    }
}
