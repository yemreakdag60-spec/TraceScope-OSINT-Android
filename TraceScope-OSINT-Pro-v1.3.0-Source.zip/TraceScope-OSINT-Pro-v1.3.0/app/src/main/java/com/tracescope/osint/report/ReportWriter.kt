package com.tracescope.osint.report

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import com.tracescope.osint.model.SearchBundle
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportWriter(private val context: Context) {

    fun writeJson(uri: Uri, bundle: SearchBundle) {
        val root = JSONObject().apply {
            put("application", "TraceScope OSINT Pro")
            put("version", "1.3.0")
            put("generatedAt", isoDate())
            put("mode", bundle.mode.name)
            put("query", bundle.query)

            bundle.phone?.let { p ->
                put("phone", JSONObject().apply {
                    put("valid", p.valid)
                    put("possible", p.possible)
                    put("international", p.international)
                    put("national", p.national)
                    put("e164", p.e164)
                    put("regionCode", p.regionCode)
                    put("countryCode", p.countryCode)
                    put("type", p.type)
                    put("originalAllocationCarrier", p.carrier)
                    put("currentCarrier", "unverified")
                    put("operatorVerificationUrl", p.operatorVerificationUrl)
                    put("geographicDescription", p.geographicDescription)
                    put("timeZones", JSONArray(p.timeZones))
                    put("webPivots", pairListToJson(p.webPivots))
                    put("error", p.error ?: JSONObject.NULL)
                })
            }

            bundle.email?.let { e ->
                put("email", JSONObject().apply {
                    put("valid", e.valid)
                    put("domain", e.domain)
                    put("localPart", e.localPart)
                    put("providerLabel", e.providerLabel)
                    put("usernameCandidates", JSONArray(e.usernameCandidates))
                    put("identityTokens", JSONArray(e.identityTokens))
                    put("webPivots", pairListToJson(e.webPivots))
                    put("domainPivots", pairListToJson(e.domainPivots))
                    put("error", e.error ?: JSONObject.NULL)
                })
            }

            bundle.domain?.let { d ->
                put("domainIntel", JSONObject().apply {
                    put("domain", d.domain)
                    put("mxHosts", JSONArray(d.mxHosts))
                    put("spfRecords", JSONArray(d.spfRecords))
                    put("dmarcRecords", JSONArray(d.dmarcRecords))
                    put("rdapLookupUrl", d.rdapLookupUrl)
                    put("notes", JSONArray(d.notes))
                    put("error", d.error ?: JSONObject.NULL)
                })
            }

            bundle.contact?.let { c ->
                put("contactCorrelation", JSONObject().apply {
                    put("direction", c.direction.name)
                    put("directionLabel", c.direction.label)
                    put("normalizedInput", c.normalizedInput)
                    put("providerHint", c.providerHint)
                    put("usernameCandidates", JSONArray(c.usernameCandidates))
                    put("phoneVariants", JSONArray(c.phoneVariants))
                    put("searchPivots", pairListToJson(c.searchPivots))
                    put("notes", JSONArray(c.notes))
                    put("error", c.error ?: JSONObject.NULL)
                })
            }

            bundle.ip?.let { i ->
                put("ip", JSONObject().apply {
                    put("success", i.success)
                    put("ip", i.ip)
                    put("country", i.country)
                    put("region", i.region)
                    put("city", i.city)
                    put("isp", i.isp)
                    put("asn", i.asn)
                    put("latitude", i.latitude ?: JSONObject.NULL)
                    put("longitude", i.longitude ?: JSONObject.NULL)
                    put("note", i.note)
                })
            }

            bundle.username?.let { u ->
                put("username", JSONObject().apply {
                    put("variants", JSONArray(u.variants))
                    put("publicEmails", JSONArray(u.publicEmails))
                    put("publicPhones", JSONArray(u.publicPhones))
                    put("locationSignals", JSONArray(u.locationSignals))
                    put("websites", JSONArray(u.websites))
                    put("displayNames", JSONArray(u.displayNames))
                    put("webPivots", pairListToJson(u.webPivots))
                    put("sourcesAttempted", u.sourcesAttempted)
                    put("websiteEvidence", JSONArray().apply {
                        u.websiteEvidence.forEach { w ->
                            put(JSONObject().apply {
                                put("url", w.url)
                                put("pageTitle", w.pageTitle)
                                put("emails", JSONArray(w.emails))
                                put("phones", JSONArray(w.phones))
                                put("locations", JSONArray(w.locations))
                                put("socialLinks", JSONArray(w.socialLinks))
                                put("status", w.status)
                                put("latencyMs", w.latencyMs)
                            })
                        }
                    })
                    put("profiles", JSONArray().apply {
                        u.profiles.forEach { hit ->
                            put(JSONObject().apply {
                                put("source", hit.source.name)
                                put("username", hit.username)
                                put("url", hit.url)
                                put("finalUrl", hit.finalUrl)
                                put("state", hit.state.name)
                                put("confidence", hit.confidence.name)
                                put("httpCode", hit.httpCode ?: JSONObject.NULL)
                                put("latencyMs", hit.latencyMs)
                                put("note", hit.note)
                                put("displayName", hit.clues.displayName ?: JSONObject.NULL)
                                put("description", hit.clues.description ?: JSONObject.NULL)
                                put("emails", JSONArray(hit.clues.emails))
                                put("phones", JSONArray(hit.clues.phones))
                                put("locations", JSONArray(hit.clues.locations))
                                put("websites", JSONArray(hit.clues.websites))
                            })
                        }
                    })
                })
            }

            bundle.person?.let { person ->
                put("publicPersonSummary", JSONObject().apply {
                    put("evidenceScore", person.evidenceScore)
                    put("evidenceLabel", person.evidenceLabel)
                    put("sourceCount", person.sourceCount)
                    put("blockedCount", person.blockedCount)
                    put("errorCount", person.errorCount)
                    put("names", JSONArray(person.names))
                    put("emails", JSONArray(person.emails))
                    put("phones", JSONArray(person.phones))
                    put("locations", JSONArray(person.locations))
                    put("websites", JSONArray(person.websites))
                    put("reasons", JSONArray(person.reasons))
                })
            }
        }

        context.contentResolver.openOutputStream(uri)?.use { output ->
            output.write(root.toString(2).toByteArray(Charsets.UTF_8))
        } ?: error("Çıktı dosyası açılamadı")
    }

    fun writePdf(uri: Uri, bundle: SearchBundle) {
        val doc = PdfDocument()
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 11f }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 20f; isFakeBoldText = true }
        val pageWidth = 595
        val pageHeight = 842
        val margin = 40f
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = doc.startPage(pageInfo)
        var canvas = page.canvas
        var y = 55f

        fun newPage() {
            doc.finishPage(page)
            pageNumber += 1
            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            page = doc.startPage(pageInfo)
            canvas = page.canvas
            y = 50f
        }

        fun line(text: String, bold: Boolean = false) {
            val paint = if (bold) Paint(bodyPaint).apply { isFakeBoldText = true } else bodyPaint
            val maxWidth = pageWidth - margin * 2
            val words = text.replace("\n", " ").split(Regex("\\s+")).filter { it.isNotBlank() }
            var current = ""

            fun drawCurrent() {
                if (current.isBlank()) return
                if (y > pageHeight - 45) newPage()
                canvas.drawText(current, margin, y, paint)
                y += 16f
                current = ""
            }

            words.forEach { word ->
                val candidate = if (current.isBlank()) word else "$current $word"
                if (paint.measureText(candidate) > maxWidth && current.isNotBlank()) {
                    drawCurrent(); current = word
                } else current = candidate
            }
            drawCurrent()
        }

        canvas.drawText("TraceScope OSINT Pro Raporu", margin, y, titlePaint)
        y += 28f
        line("Sürüm: 1.3.0")
        line("Oluşturulma: ${humanDate()}")
        line("Araştırma türü: ${bundle.mode.label}")
        line("Sorgu: ${bundle.query}", true)
        y += 8f

        bundle.phone?.let { p ->
            line("Telefon Analizi", true)
            line("Geçerli: ${p.valid} | Olası: ${p.possible}")
            if (p.international.isNotBlank()) line("Uluslararası: ${p.international}")
            if (p.e164.isNotBlank()) line("E.164: ${p.e164}")
            if (p.regionCode.isNotBlank()) line("Bölge: ${p.regionCode}")
            if (p.type.isNotBlank()) line("Hat türü: ${p.type}")
            if (p.carrier.isNotBlank()) line("İlk tahsis / numara bloğu: ${p.carrier}")
            line("Güncel operatör: Resmî doğrulama gerekli")
            if (p.operatorVerificationUrl.isNotBlank()) line("Operatör doğrulama: ${p.operatorVerificationUrl}")
            if (p.geographicDescription.isNotBlank()) line("Numara bölgesi: ${p.geographicDescription}")
            if (p.timeZones.isNotEmpty()) line("Saat dilimleri: ${p.timeZones.joinToString()}")
            p.error?.let { line("Hata: $it") }
            y += 6f
        }

        bundle.email?.let { e ->
            line("E-posta Analizi", true)
            line("Geçerli: ${e.valid}")
            if (e.domain.isNotBlank()) line("Alan adı: ${e.domain}")
            if (e.providerLabel.isNotBlank()) line("Sağlayıcı: ${e.providerLabel}")
            if (e.identityTokens.isNotEmpty()) line("Kimlik parçaları: ${e.identityTokens.joinToString()}")
            if (e.usernameCandidates.isNotEmpty()) line("Kullanıcı adı adayları: ${e.usernameCandidates.joinToString()}")
            e.error?.let { line("Hata: $it") }
            y += 6f
        }

        bundle.domain?.let { d ->
            line("Alan Adı Teknik İstihbaratı", true)
            line("Alan adı: ${d.domain}")
            if (d.mxHosts.isNotEmpty()) line("MX: ${d.mxHosts.joinToString()}")
            line("SPF: ${if (d.spfRecords.isNotEmpty()) "Bulundu" else "Görünmedi"}")
            line("DMARC: ${if (d.dmarcRecords.isNotEmpty()) "Bulundu" else "Görünmedi"}")
            if (d.rdapLookupUrl.isNotBlank()) line("RDAP: ${d.rdapLookupUrl}")
            d.notes.forEach { line("• $it") }
            d.error?.let { line("Hata: $it") }
            y += 6f
        }

        bundle.contact?.let { c ->
            line("E-posta ↔ Telefon Korelasyonu", true)
            line("Yön: ${c.direction.label}")
            line("Normalize giriş: ${c.normalizedInput}")
            if (c.providerHint.isNotBlank()) line("Sağlayıcı/ilk tahsis: ${c.providerHint}")
            if (c.usernameCandidates.isNotEmpty()) line("Kullanıcı adı adayları: ${c.usernameCandidates.joinToString()}")
            if (c.phoneVariants.isNotEmpty()) line("Numara varyasyonları: ${c.phoneVariants.joinToString()}")
            c.notes.forEach { line("• $it") }
            c.error?.let { line("Hata: $it") }
            y += 6f
        }

        bundle.ip?.let { i ->
            line("IP Analizi", true)
            if (i.success) {
                line("${i.ip} — ${listOf(i.city, i.region, i.country).filter { it.isNotBlank() }.joinToString(", ")}")
                if (i.isp.isNotBlank()) line("ISP: ${i.isp}")
                if (i.asn.isNotBlank()) line("ASN: ${i.asn}")
            }
            line(i.note)
            y += 6f
        }

        bundle.person?.let { person ->
            line("Kişi Kanıt Özeti", true)
            line("Kanıt kapsam skoru: %${person.evidenceScore} — ${person.evidenceLabel}")
            line("Kaynak: ${person.sourceCount} | Profil adayı: ${person.profileHits.size} | Engelli/doğrulama: ${person.blockedCount} | Hata: ${person.errorCount}")
            if (person.names.isNotEmpty()) line("Görünen adlar: ${person.names.joinToString()}")
            if (person.emails.isNotEmpty()) line("Kamuya açık e-postalar: ${person.emails.joinToString()}")
            if (person.phones.isNotEmpty()) line("Kamuya açık telefonlar: ${person.phones.joinToString()}")
            if (person.locations.isNotEmpty()) line("Konum sinyalleri: ${person.locations.joinToString()}")
            if (person.websites.isNotEmpty()) line("Web/domain: ${person.websites.joinToString()}")
            person.reasons.forEach { line("• $it") }
            y += 6f
        }

        bundle.username?.let { u ->
            line("Kullanıcı Adı Analizi", true)
            line("Varyasyonlar: ${u.variants.joinToString()}")
            line("Denenen kaynak: ${u.sourcesAttempted}")
            if (u.publicEmails.isNotEmpty()) line("Açık e-postalar: ${u.publicEmails.joinToString()}")
            if (u.publicPhones.isNotEmpty()) line("Açık telefonlar: ${u.publicPhones.joinToString()}")
            if (u.locationSignals.isNotEmpty()) line("Açık konum sinyalleri: ${u.locationSignals.joinToString()}")
            if (u.websites.isNotEmpty()) line("Bağlantılı web: ${u.websites.joinToString()}")
            if (u.websiteEvidence.isNotEmpty()) {
                line("Açık web zenginleştirme:", true)
                u.websiteEvidence.take(12).forEach { w ->
                    line("${w.url} — ${w.status}")
                    if (w.emails.isNotEmpty()) line("  E-posta: ${w.emails.joinToString()}")
                    if (w.phones.isNotEmpty()) line("  Telefon: ${w.phones.joinToString()}")
                    if (w.locations.isNotEmpty()) line("  Konum: ${w.locations.joinToString()}")
                    if (w.socialLinks.isNotEmpty()) line("  Sosyal: ${w.socialLinks.joinToString()}")
                }
            }
            y += 6f
            u.profiles.filter { it.state.name != "NOT_FOUND" }.take(100).forEach { hit ->
                line("${hit.source.name} @${hit.username} — ${hit.state} / ${hit.confidence}", true)
                line(hit.finalUrl)
                if (hit.note.isNotBlank()) line(hit.note)
                hit.clues.displayName?.takeIf { it.isNotBlank() }?.let { line("Görünen ad: $it") }
                hit.clues.description?.takeIf { it.isNotBlank() }?.let { line("Açıklama: $it") }
                if (hit.clues.emails.isNotEmpty()) line("Açık e-posta: ${hit.clues.emails.joinToString()}")
                if (hit.clues.phones.isNotEmpty()) line("Açık telefon: ${hit.clues.phones.joinToString()}")
                if (hit.clues.locations.isNotEmpty()) line("Konum sinyali: ${hit.clues.locations.joinToString()}")
                y += 4f
            }
        }

        y += 8f
        line("Not: Bu rapor yalnızca kamuya açık/izinli kaynak sinyallerini içerir. Gizli kayıt e-postası/telefonu, parola/OTP, özel mesaj veya canlı GPS çıkarmaz.")

        doc.finishPage(page)
        context.contentResolver.openOutputStream(uri)?.use { output -> doc.writeTo(output) }
            ?: error("PDF çıktı dosyası açılamadı")
        doc.close()
    }

    private fun pairListToJson(items: List<Pair<String, String>>): JSONArray = JSONArray().apply {
        items.forEach { (name, url) ->
            put(JSONObject().apply { put("name", name); put("url", url) })
        }
    }

    private fun isoDate(): String = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date())
    private fun humanDate(): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date())
}
