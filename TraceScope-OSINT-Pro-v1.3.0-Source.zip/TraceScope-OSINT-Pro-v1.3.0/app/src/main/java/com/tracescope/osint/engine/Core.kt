package com.tracescope.osint.engine

import com.tracescope.osint.model.CorrelationPair
import com.tracescope.osint.model.ProfileHit
import kotlin.math.max

object UsernameVariantGenerator {
    fun generate(input: String, discoveredDisplayNames: List<String> = emptyList(), limit: Int = 18): List<String> {
        val clean = input.trim().removePrefix("@").lowercase()
        if (clean.isBlank()) return emptyList()

        val out = LinkedHashSet<String>()
        fun add(v: String) {
            val normalized = v.trim().trim('.', '_', '-').lowercase()
            if (normalized.length in 2..40 && normalized.matches(Regex("[a-z0-9._-]+"))) out += normalized
        }

        add(clean)
        add(clean.replace(".", ""))
        add(clean.replace("_", ""))
        add(clean.replace("-", ""))

        val tokens = clean.split('.', '_', '-').filter { it.isNotBlank() }
        if (tokens.size >= 2) {
            val first = tokens.first()
            val last = tokens.last()
            listOf(".", "_", "-", "").forEach { sep ->
                add("$first$sep$last")
                add("$last$sep$first")
            }
        }

        val trailing = Regex("^([a-z._-]+?)(\\d{1,4})$").matchEntire(clean)
        if (trailing != null) {
            add(trailing.groupValues[1])
            add(trailing.groupValues[1].replace(Regex("[._-]"), ""))
        }

        discoveredDisplayNames.take(3).forEach { display ->
            val nameTokens = display.lowercase()
                .replace(Regex("[^a-z0-9çğıöşü\\s-]"), " ")
                .split(Regex("\\s+"))
                .map { transliterateTr(it) }
                .filter { it.length >= 2 }
            if (nameTokens.size >= 2) {
                val first = nameTokens.first()
                val last = nameTokens.last()
                listOf("", ".", "_").forEach { sep ->
                    add("$first$sep$last")
                    add("$last$sep$first")
                }
            }
        }

        return out.take(limit)
    }

    private fun transliterateTr(value: String): String = value
        .replace('ç', 'c').replace('ğ', 'g').replace('ı', 'i')
        .replace('ö', 'o').replace('ş', 's').replace('ü', 'u')
}

object Similarity {
    fun normalized(a: String?, b: String?): Double {
        val x = a.orEmpty().trim().lowercase()
        val y = b.orEmpty().trim().lowercase()
        if (x.isBlank() || y.isBlank()) return 0.0
        if (x == y) return 1.0
        val distance = levenshtein(x, y)
        return 1.0 - (distance.toDouble() / max(x.length, y.length).toDouble())
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var curr = IntArray(b.length + 1)
        for (i in 1..a.length) {
            curr[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                curr[j] = minOf(curr[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = curr; curr = tmp
        }
        return prev[b.length]
    }
}

object CorrelationEngine {
    fun pairwise(profiles: List<ProfileHit>): List<CorrelationPair> {
        val usable = profiles.filter { it.state.name in setOf("CONFIRMED", "LIKELY", "AMBIGUOUS") }
        val out = mutableListOf<CorrelationPair>()
        for (i in usable.indices) for (j in i + 1 until usable.size) {
            val a = usable[i]
            val b = usable[j]
            val reasons = mutableListOf<String>()
            var score = 0

            if (a.username.equals(b.username, ignoreCase = true)) {
                score += 25; reasons += "Aynı kullanıcı adı"
            } else {
                val s = Similarity.normalized(a.username, b.username)
                if (s >= 0.80) { score += 14; reasons += "Benzer kullanıcı adı" }
            }

            val nameSim = Similarity.normalized(a.clues.displayName, b.clues.displayName)
            if (nameSim >= 0.90) { score += 22; reasons += "Görünen ad çok benzer" }
            else if (nameSim >= 0.75) { score += 12; reasons += "Görünen ad benzer" }

            val commonEmails = a.clues.emails.map { it.lowercase() }.toSet() intersect b.clues.emails.map { it.lowercase() }.toSet()
            if (commonEmails.isNotEmpty()) { score += 35; reasons += "Ortak açık e-posta" }

            val commonPhones = a.clues.phones.toSet() intersect b.clues.phones.toSet()
            if (commonPhones.isNotEmpty()) { score += 35; reasons += "Ortak açık telefon" }

            val commonSites = a.clues.websites.map(::hostOnly).filter { it.isNotBlank() }.toSet() intersect
                b.clues.websites.map(::hostOnly).filter { it.isNotBlank() }.toSet()
            if (commonSites.isNotEmpty()) { score += 22; reasons += "Ortak web alan adı" }

            val commonLocations = a.clues.locations.map { it.lowercase() }.toSet() intersect b.clues.locations.map { it.lowercase() }.toSet()
            if (commonLocations.isNotEmpty()) { score += 12; reasons += "Ortak açık konum sinyali" }

            out += CorrelationPair(a, b, score.coerceAtMost(100), reasons)
        }
        return out.sortedByDescending { it.score }
    }

    private fun hostOnly(url: String): String = url
        .lowercase()
        .removePrefix("https://")
        .removePrefix("http://")
        .removePrefix("www.")
        .substringBefore('/')
}
