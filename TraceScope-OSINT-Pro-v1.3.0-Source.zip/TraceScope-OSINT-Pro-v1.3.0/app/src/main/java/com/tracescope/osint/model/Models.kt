package com.tracescope.osint.model

enum class SearchMode(val label: String) {
    PHONE("Telefon"), USERNAME("Kullanıcı adı"), EMAIL("E-posta"), CONTACT_LINK("E-posta ↔ Telefon"), IP("IP")
}

enum class ContactDirection(val label: String) {
    PHONE_TO_EMAIL("Telefon → E-posta"),
    EMAIL_TO_PHONE("E-posta → Telefon")
}

data class ContactCorrelationIntel(
    val input: String,
    val direction: ContactDirection,
    val normalizedInput: String,
    val providerHint: String = "",
    val usernameCandidates: List<String> = emptyList(),
    val phoneVariants: List<String> = emptyList(),
    val searchPivots: List<Pair<String, String>> = emptyList(),
    val notes: List<String> = emptyList(),
    val error: String? = null
)

enum class ProbeState { CONFIRMED, LIKELY, AMBIGUOUS, NOT_FOUND, BLOCKED, ERROR }

enum class Confidence(val label: String) {
    HIGH("Yüksek"), MEDIUM("Orta"), LOW("Düşük"), UNKNOWN("Belirsiz")
}

data class PlatformSource(
    val name: String,
    val urlTemplate: String,
    val reliableHttp200: Boolean = false,
    val notFoundMarkers: List<String> = emptyList()
)

data class PublicClues(
    val displayName: String? = null,
    val description: String? = null,
    val emails: List<String> = emptyList(),
    val phones: List<String> = emptyList(),
    val locations: List<String> = emptyList(),
    val websites: List<String> = emptyList()
)

data class ProfileHit(
    val source: PlatformSource,
    val username: String,
    val url: String,
    val finalUrl: String,
    val state: ProbeState,
    val confidence: Confidence,
    val httpCode: Int?,
    val latencyMs: Long,
    val note: String,
    val clues: PublicClues = PublicClues()
)

data class WebsiteEvidence(
    val url: String,
    val pageTitle: String = "",
    val emails: List<String> = emptyList(),
    val phones: List<String> = emptyList(),
    val locations: List<String> = emptyList(),
    val socialLinks: List<String> = emptyList(),
    val status: String = "",
    val latencyMs: Long = 0
)

data class DomainIntel(
    val domain: String,
    val mxHosts: List<String> = emptyList(),
    val spfRecords: List<String> = emptyList(),
    val dmarcRecords: List<String> = emptyList(),
    val rdapLookupUrl: String = "",
    val notes: List<String> = emptyList(),
    val error: String? = null
)

data class PhoneIntel(
    val input: String,
    val valid: Boolean,
    val possible: Boolean,
    val international: String = "",
    val national: String = "",
    val e164: String = "",
    val regionCode: String = "",
    val countryCode: Int = 0,
    val type: String = "",
    val carrier: String = "",
    val geographicDescription: String = "",
    val timeZones: List<String> = emptyList(),
    val webPivots: List<Pair<String, String>> = emptyList(),
    val operatorVerificationUrl: String = "",
    val error: String? = null
)

data class EmailIntel(
    val input: String,
    val valid: Boolean,
    val localPart: String = "",
    val domain: String = "",
    val providerLabel: String = "",
    val usernameCandidates: List<String> = emptyList(),
    val identityTokens: List<String> = emptyList(),
    val webPivots: List<Pair<String, String>> = emptyList(),
    val domainPivots: List<Pair<String, String>> = emptyList(),
    val error: String? = null
)

data class IpIntel(
    val input: String,
    val success: Boolean,
    val ip: String = "",
    val country: String = "",
    val region: String = "",
    val city: String = "",
    val isp: String = "",
    val asn: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val note: String = ""
)

data class UsernameIntel(
    val input: String,
    val variants: List<String>,
    val profiles: List<ProfileHit>,
    val publicEmails: List<String>,
    val publicPhones: List<String>,
    val locationSignals: List<String>,
    val websites: List<String>,
    val displayNames: List<String>,
    val webPivots: List<Pair<String, String>> = emptyList(),
    val websiteEvidence: List<WebsiteEvidence> = emptyList(),
    val sourcesAttempted: Int
)

data class PublicPersonSummary(
    val names: List<String> = emptyList(),
    val emails: List<String> = emptyList(),
    val phones: List<String> = emptyList(),
    val locations: List<String> = emptyList(),
    val websites: List<String> = emptyList(),
    val profileHits: List<ProfileHit> = emptyList(),
    val evidenceScore: Int = 0,
    val evidenceLabel: String = "Yetersiz",
    val reasons: List<String> = emptyList(),
    val sourceCount: Int = 0,
    val blockedCount: Int = 0,
    val errorCount: Int = 0
)

data class SearchBundle(
    val mode: SearchMode,
    val query: String,
    val startedAtEpochMs: Long = System.currentTimeMillis(),
    val phone: PhoneIntel? = null,
    val email: EmailIntel? = null,
    val contact: ContactCorrelationIntel? = null,
    val ip: IpIntel? = null,
    val username: UsernameIntel? = null,
    val domain: DomainIntel? = null,
    val person: PublicPersonSummary? = null
)

data class CorrelationPair(
    val left: ProfileHit,
    val right: ProfileHit,
    val score: Int,
    val reasons: List<String>
)
