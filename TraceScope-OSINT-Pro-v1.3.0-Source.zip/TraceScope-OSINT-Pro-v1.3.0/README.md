# TraceScope OSINT Pro v1.3.0

Native Android/Kotlin + Jetpack Compose ile hazırlanmış, **yalnızca kamuya açık/izinli kaynakları** kullanan OSINT araştırma uygulaması.

## v1.3.0 — tamamlanan profesyonel akış

### E-posta → kişi / telefon / sosyal medya
- Gmail, Outlook/Hotmail/Live, Yahoo, Proton, iCloud ve kurumsal alan adı sınıflandırması.
- E-posta yerel parçasından kullanıcı adı adayları ve ad-soyad benzeri kimlik parçaları üretir.
- İlk 1–3 güçlü kullanıcı adı adayını otomatik olarak Instagram, Facebook, X, TikTok, LinkedIn, Threads, Telegram, GitHub ve diğer platformlarda tarar.
- Açık profil sayfalarındaki `mailto:`, `tel:`, JSON-LD `email`, `telephone`, `addressLocality`, `sameAs`, meta başlık/açıklama ve bağlantıları çıkarır.
- Profillerden bulunan kişisel/kurumsal web sitelerini bir adım daha zenginleştirir; ana sayfa ile açık `contact/iletişim/about/hakkımızda/team/ekip` sayfalarından kamuya açık telefon, e-posta, konum ve sosyal bağlantıları toplar.
- Sonuçları tek **Kişi Kanıt Özeti** altında, kaynak kapsam skoru ve gerekçeleriyle birleştirir.

### Kullanıcı adı → tüm açık sinyaller
- Exact kullanıcı adı + nokta/alt çizgi/tire/kısaltma/ad-soyad varyasyonları.
- 25 platformluk kaynak kayıt defteri.
- Doğrulandı / Muhtemel / Belirsiz / Tarayıcı doğrulaması / Bulunamadı / Hata durumları.
- Kamuya açık telefon, e-posta, konum, web sitesi ve görünen ad sinyalleri.
- Bulunan web sitelerinde sınırlı, güvenli bir adım zenginleştirme.
- Hesaplar arası ortak telefon/e-posta/domain/ad/konum sinyalleriyle açıklanabilir korelasyon.

### Telefon
- libphonenumber ile geçerlilik, E.164, ulusal/uluslararası biçim, hat türü, ülke/bölge, saat dilimi.
- Taşınabilirlik nedeniyle carrier sonucu **“İlk tahsis / numara bloğu”** olarak gösterilir.
- Türkiye numaralarında **BTK/e-Devlet Numara Taşıma Sorgulama** bağlantısı ile güncel operatör resmî kaynaktan doğrulanır.
- Telefon numarasının farklı açık gösterim biçimleriyle web/sosyal pivotları.

### Profesyonel ekler
- E-posta domaini için DNS-over-HTTPS ile MX, SPF ve DMARC görünürlüğü.
- RDAP alan adı kaydı bağlantısı.
- Kaynak sağlığı: blocked/error sayısı, HTTP durumu ve gecikme.
- Yerel/özel ağ adreslerine otomatik web isteği engeli (SSRF koruması).
- Tek kaynak hatasında tüm araştırmayı durdurmayan hata izolasyonu.
- PDF ve JSON raporu; her bulgu için kaynak ve teknik bağlam.
- Otomatik araştırma geçmişi saklanmaz.

## Bilinçli sınırlar
TraceScope gizli hesap kayıt e-postası/telefonu, parola/OTP, özel mesaj, özel API verisi veya canlı GPS elde etmeye çalışmaz. Bir platform otomasyonu engellerse erişim kontrolünü aşmaz; sonucu **Tarayıcıda doğrula** olarak gösterir. Elde edilen açık sinyaller gerçek kişi kimliği için tek başına kesin kanıt sayılmaz.

## Android
- applicationId: `com.tracescope.osint`
- minSdk: 26
- targetSdk / compileSdk: 35
- versionCode: 130
- versionName: `1.3.0`
- JDK: 17
- Gradle: 8.9

## GitHub Actions
`.github/workflows/android.yml`:
1. JDK 17 + Gradle 8.9
2. Unit test
3. Android Lint raporu (bulgular raporlanır; APK üretimini gereksiz yere durdurmaz)
4. Debug APK derleme
5. `TraceScope-OSINT-Pro-v1.3.0-APK` Artifact yükleme

APK: `app/build/outputs/apk/debug/app-debug.apk`
